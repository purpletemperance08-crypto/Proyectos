﻿using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    public partial class FormEditarCatalog : Form
    {
        private readonly int _idCatalog;
        // Asumo que tienes una clase InventarioItem en Models
        private CatalogRepositorie _repo = new CatalogRepositorie();

        // Constructor principal que recibe el ID del artículo a editar
        public FormEditarCatalog(int idCatalog)
        {
            InitializeComponent();
            _idCatalog = idCatalog;
            this.Text = "Editar Artículo de Catálogo ID: " + idCatalog.ToString();
            CargarDatosItem();
            // Aseguramos que la etiqueta 3 diga "Stock" y no "Precio"
            label3.Text = "Stock";
        }

        // Constructor vacío (si es requerido por el diseñador)
        public FormEditarCatalog()
        {
            InitializeComponent();
        }

        // --- Lógica de Carga de Datos ---
        private void CargarDatosItem()
        {
            if (_idCatalog <= 0)
            {
                MessageBox.Show("Error: ID de artículo de catálogo no válido para la edición.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            try
            {
                // Asumo que el método GetItemById existe y devuelve un objeto InventarioItem o similar
                InventarioItem item = _repo.GetItemById(_idCatalog);

                if (item != null)
                {
                    textBoxName.Text = item.name;
                    textBoxDescription.Text = item.description;
                    // Cargar el Stock en el control correspondiente
                    textBoxStock.Text = item.stock.ToString();
                }
                else
                {
                    MessageBox.Show("No se pudieron cargar los datos del artículo de catálogo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos: {ex.Message}", "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        // --- Lógica de Guardar Cambios (Adaptada de btnGuardar_Click_1) ---
        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            string nuevoNombre = textBoxName.Text.Trim();
            string nuevaDescripcion = textBoxDescription.Text.Trim();
            string stockStr = textBoxStock.Text.Trim();

            // 1. Validación de campos vacíos
            if (string.IsNullOrEmpty(nuevoNombre) || string.IsNullOrEmpty(nuevaDescripcion) || string.IsNullOrEmpty(stockStr))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 2. Validación de Stock (debe ser un entero no negativo)
            if (!int.TryParse(stockStr, out int nuevoStock) || nuevoStock < 0)
            {
                MessageBox.Show("Por favor, ingrese un valor de Stock válido (número entero positivo o cero).", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxStock.Focus();
                return;
            }

            try
            {

                _repo.UpdateItem(_idCatalog, nuevoNombre, nuevaDescripcion, nuevoStock);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error al guardar cambios en el catálogo: {ex.Message}", "Error de Actualización", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}