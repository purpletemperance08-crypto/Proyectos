﻿using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Windows.Forms;
using System.Linq;

namespace PetitPlannerIntegrador
{
    // UserControl que muestra la lista del catálogo (DataGridView)
    public partial class añadirCatalog : UserControl
    {
        // Eventos de navegación (si los usas)
        public event EventHandler Cancelar;
        public event EventHandler VolverAtras;

        public añadirCatalog()
        {
            InitializeComponent();

            // 1. Configuración del DataGridView
            catalogDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            cargarDatosCatalogo();

            // 2. Suscripción de eventos a los botones de acción
            // Los botones ahora coinciden con los nombres que proporcionaste: añadir, editar, eliminar.
            eliminar.Click += EliminarCatalogo_Click;
            editar.Click += EditarCatalogo_Click;
            añadir.Click += AñadirCatalogo_Click;
        }

        // ----------------------------------------------------------------------
        // LÓGICA DE CARGA DE DATOS
        // ----------------------------------------------------------------------

        public void cargarDatosCatalogo()
        {
            string idInventario = SessionManager.CurrentIdInventory;

            if (string.IsNullOrEmpty(idInventario))
            {
                catalogDataGridView.DataSource = null;
                MessageBox.Show("Error: ID de Inventario no cargado.", "Error de Sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                CatalogRepositorie repo = new CatalogRepositorie();
                var itemsCatalogo = repo.GetCatalogItemsByInventoryId(idInventario);

                // Asignación al DataGridView
                catalogDataGridView.DataSource = itemsCatalogo;

                // Configuración de columnas (Ocultar IDs)
                if (catalogDataGridView.Columns.Contains("id_inventory"))
                {
                    catalogDataGridView.Columns["id_inventory"].Visible = false;
                }

                if (catalogDataGridView.Columns.Contains("id_catalog"))
                {
                    catalogDataGridView.Columns["id_catalog"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error al cargar los datos del catálogo: {ex.Message}", "Error de BD");
                catalogDataGridView.DataSource = null;
            }
        }

        // ----------------------------------------------------------------------
        // MANEJADORES DE BOTONES
        // ----------------------------------------------------------------------

        // AÑADIR (Temporal)
        private void AñadirCatalogo_Click(object sender, EventArgs e)
        {
        }

        // EDITAR (Temporal)
        private void EditarCatalogo_Click(object sender, EventArgs e)
        {
            if (catalogDataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, seleccione una fila completa para editar.", "Advertencia");
                return;
            }

            DataGridViewRow selectedRow = catalogDataGridView.SelectedRows[0];
            // Aseguramos que el valor sea un entero antes de pasarlo al mensaje
            if (!int.TryParse(selectedRow.Cells["id_catalog"].Value?.ToString(), out int idCatalogo))
            {
                MessageBox.Show("Error al obtener el ID del artículo.", "Error");
                return;
            }

        }

        // ELIMINAR (FUNCIONAL)
        private void EliminarCatalogo_Click(object sender, EventArgs e)
        {
            if (catalogDataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, seleccione una fila completa para eliminar.", "Advertencia");
                return;
            }

            // Obtener el ID del Catálogo (id_catalog)
            if (!int.TryParse(catalogDataGridView.SelectedRows[0].Cells["id_catalog"].Value?.ToString(), out int idCatalogo))
            {
                MessageBox.Show("Error al obtener el ID del artículo para eliminar.", "Error");
                return;
            }

            DialogResult confirm = MessageBox.Show(
                $"¿Estás seguro de que quieres eliminar el producto?",
                    "Confirmar Eliminación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                try
                {
                    CatalogRepositorie repo = new CatalogRepositorie();
                    repo.DeleteItem(idCatalogo);

                    MessageBox.Show("✅ Artículo de catálogo eliminado exitosamente.");
                    cargarDatosCatalogo(); // Recargar la lista
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"❌ Error al eliminar el artículo del catálogo: {ex.Message}");
                }
            }
        }

        // ----------------------------------------------------------------------
        // NAVEGACIÓN
        // ----------------------------------------------------------------------

        private void atras_Click(object sender, EventArgs e) => Cancelar?.Invoke(this, EventArgs.Empty);
        private void backInventory_Click(object sender, EventArgs e) => VolverAtras?.Invoke(this, EventArgs.Empty);

        private void editar_Click(object sender, EventArgs e) // Este es el evento para tu botón 'editar'
        {
            // 1. Validar selección en el DataGridView del Catálogo
            if (catalogDataGridView.SelectedRows.Count == 0) // <--- ¡AQUÍ ESTÁ LA CORRECCIÓN!
            {
                MessageBox.Show("Por favor, seleccione una fila completa para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            DataGridViewRow selectedRow = catalogDataGridView.SelectedRows[0];

            // 2. Obtener el ID del Catálogo (id_catalog)
            // Usamos 'catalogGridView' para obtener la fila, y la columna 'id_catalog'
            if (!int.TryParse(selectedRow.Cells["id_catalog"].Value?.ToString(), out int idCatalogo))
            {
                MessageBox.Show("Error al obtener el ID del artículo de catálogo.", "Error de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 3. Abrir el formulario de edición del Catálogo
            using (FormEditarCatalog formEdicion = new FormEditarCatalog(idCatalogo))
            {
                formEdicion.StartPosition = FormStartPosition.CenterScreen;

                DialogResult result = formEdicion.ShowDialog();

                // 4. Recargar los datos si la edición fue exitosa
                if (result == DialogResult.OK)
                {
                    cargarDatosCatalogo();
                }
            }
        }

        private void añadir_Click(object sender, EventArgs e) // Asegúrate de que el botón 'añadir' esté suscrito a esta función
        {
            string idInventarioActual = SessionManager.CurrentIdInventory;

            if (string.IsNullOrEmpty(idInventarioActual))
            {
                MessageBox.Show("Error: El ID de Inventario no está cargado en la sesión.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 🛑 CAMBIO CLAVE: Llamar al formulario de adición de Catálogo
            using (FormAñadirCatalog formAñadir = new FormAñadirCatalog(idInventarioActual))
            {
                formAñadir.StartPosition = FormStartPosition.CenterScreen;

                DialogResult result = formAñadir.ShowDialog();

                if (result == DialogResult.OK)
                {
                    // 🛑 CAMBIO CLAVE: Recargar los datos del Catálogo
                    cargarDatosCatalogo();
                }
            }
        }

        private void backCatalog_Click(object sender, EventArgs e)
        {
            VolverAtras?.Invoke(this, EventArgs.Empty);

        }

        private void eliminar_Click(object sender, EventArgs e)
        {

        }
    }
}