﻿namespace PetitPlannerIntegrador
{
    partial class agendarEvento
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Profile = new Button();
            Agendar = new Button();
            Calendario = new Button();
            Inventario = new Button();
            Catalogo = new Button();
            Home = new Button();
            panel2 = new Panel();
            label10 = new Label();
            label11 = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            panelContenido = new Panel();
            label8 = new Label();
            panel8 = new Panel();
            nameLabel = new TextBox();
            label2 = new Label();
            panel6 = new Panel();
            numberPhoneEvent = new TextBox();
            label4 = new Label();
            dateEvent = new DateTimePicker();
            label6 = new Label();
            hourEvent = new DateTimePicker();
            label7 = new Label();
            panel11 = new Panel();
            typeEvent = new TextBox();
            label3 = new Label();
            panel10 = new Panel();
            ubicationEvent = new TextBox();
            label9 = new Label();
            panel9 = new Panel();
            descriptionLabel = new TextBox();
            label1 = new Label();
            panel7 = new Panel();
            montoEvent = new TextBox();
            button3 = new Button();
            button1 = new Button();
            panel5 = new Panel();
            label5 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panelContenido.SuspendLayout();
            panel8.SuspendLayout();
            panel6.SuspendLayout();
            panel11.SuspendLayout();
            panel10.SuspendLayout();
            panel9.SuspendLayout();
            panel7.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.FromArgb(12, 67, 122);
            panel1.Controls.Add(Profile);
            panel1.Controls.Add(Agendar);
            panel1.Controls.Add(Calendario);
            panel1.Controls.Add(Inventario);
            panel1.Controls.Add(Catalogo);
            panel1.Controls.Add(Home);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 786);
            panel1.TabIndex = 38;
            // 
            // Profile
            // 
            Profile.BackColor = Color.FromArgb(12, 67, 122);
            Profile.Dock = DockStyle.Top;
            Profile.FlatAppearance.BorderSize = 0;
            Profile.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Profile.FlatStyle = FlatStyle.Flat;
            Profile.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Profile.ForeColor = Color.White;
            Profile.Image = Properties.Resources.perfil_blanco_27;
            Profile.Location = new Point(0, 819);
            Profile.Margin = new Padding(3, 4, 3, 4);
            Profile.Name = "Profile";
            Profile.Padding = new Padding(22, 0, 0, 0);
            Profile.Size = new Size(274, 124);
            Profile.TabIndex = 3;
            Profile.Text = "     Profile";
            Profile.TextImageRelation = TextImageRelation.ImageBeforeText;
            Profile.UseVisualStyleBackColor = false;
            Profile.Click += button4_Click;
            // 
            // Agendar
            // 
            Agendar.BackColor = Color.FromArgb(232, 239, 253);
            Agendar.Dock = DockStyle.Top;
            Agendar.FlatAppearance.BorderSize = 0;
            Agendar.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Agendar.FlatStyle = FlatStyle.Flat;
            Agendar.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Agendar.ForeColor = Color.FromArgb(12, 67, 122);
            Agendar.Image = Properties.Resources.agendar_azulobsucuro_27;
            Agendar.Location = new Point(0, 695);
            Agendar.Margin = new Padding(3, 4, 3, 4);
            Agendar.Name = "Agendar";
            Agendar.Padding = new Padding(30, 0, 0, 0);
            Agendar.Size = new Size(274, 124);
            Agendar.TabIndex = 2;
            Agendar.Text = "     Schedule";
            Agendar.TextImageRelation = TextImageRelation.ImageBeforeText;
            Agendar.UseVisualStyleBackColor = false;
            // 
            // Calendario
            // 
            Calendario.BackColor = Color.FromArgb(12, 67, 122);
            Calendario.Dock = DockStyle.Top;
            Calendario.FlatAppearance.BorderSize = 0;
            Calendario.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Calendario.FlatStyle = FlatStyle.Flat;
            Calendario.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Calendario.ForeColor = Color.White;
            Calendario.Image = Properties.Resources.calendario_blanco_27;
            Calendario.Location = new Point(0, 571);
            Calendario.Margin = new Padding(3, 4, 3, 4);
            Calendario.Name = "Calendario";
            Calendario.Padding = new Padding(32, 0, 0, 0);
            Calendario.Size = new Size(274, 124);
            Calendario.TabIndex = 1;
            Calendario.Text = "    Calendar";
            Calendario.TextImageRelation = TextImageRelation.ImageBeforeText;
            Calendario.UseVisualStyleBackColor = false;
            Calendario.Click += calendario_Click;
            // 
            // Inventario
            // 
            Inventario.BackColor = Color.FromArgb(12, 67, 122);
            Inventario.Dock = DockStyle.Top;
            Inventario.FlatAppearance.BorderSize = 0;
            Inventario.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Inventario.FlatStyle = FlatStyle.Flat;
            Inventario.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Inventario.ForeColor = Color.White;
            Inventario.Image = Properties.Resources.inventario_blanca_27;
            Inventario.Location = new Point(0, 447);
            Inventario.Margin = new Padding(3, 4, 3, 4);
            Inventario.Name = "Inventario";
            Inventario.Padding = new Padding(28, 0, 0, 0);
            Inventario.Size = new Size(274, 124);
            Inventario.TabIndex = 5;
            Inventario.Text = "     Inventory";
            Inventario.TextImageRelation = TextImageRelation.ImageBeforeText;
            Inventario.UseVisualStyleBackColor = false;
            Inventario.Click += inventary_Click;
            // 
            // Catalogo
            // 
            Catalogo.BackColor = Color.FromArgb(12, 67, 122);
            Catalogo.Dock = DockStyle.Top;
            Catalogo.FlatAppearance.BorderSize = 0;
            Catalogo.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Catalogo.FlatStyle = FlatStyle.Flat;
            Catalogo.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Catalogo.ForeColor = Color.White;
            Catalogo.Image = Properties.Resources.catalogo_blanco_27;
            Catalogo.Location = new Point(0, 323);
            Catalogo.Margin = new Padding(3, 4, 3, 4);
            Catalogo.Name = "Catalogo";
            Catalogo.Padding = new Padding(28, 0, 0, 0);
            Catalogo.Size = new Size(274, 124);
            Catalogo.TabIndex = 0;
            Catalogo.Text = "     Catalog";
            Catalogo.TextImageRelation = TextImageRelation.ImageBeforeText;
            Catalogo.UseVisualStyleBackColor = false;
            Catalogo.Click += Catalogo_Click;
            // 
            // Home
            // 
            Home.BackColor = Color.FromArgb(12, 67, 122);
            Home.Dock = DockStyle.Top;
            Home.FlatAppearance.BorderSize = 0;
            Home.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Home.FlatStyle = FlatStyle.Flat;
            Home.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Home.ForeColor = Color.White;
            Home.Image = Properties.Resources.casa_blanca_27;
            Home.Location = new Point(0, 199);
            Home.Margin = new Padding(3, 4, 3, 4);
            Home.Name = "Home";
            Home.Padding = new Padding(22, 0, 0, 0);
            Home.Size = new Size(274, 124);
            Home.TabIndex = 4;
            Home.Text = "     Home";
            Home.TextImageRelation = TextImageRelation.ImageBeforeText;
            Home.UseVisualStyleBackColor = false;
            Home.Click += homePage_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(label10);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(panel3);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(274, 199);
            panel2.TabIndex = 0;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label10.ForeColor = Color.White;
            label10.Location = new Point(27, 109);
            label10.Name = "label10";
            label10.Size = new Size(165, 47);
            label10.TabIndex = 7;
            label10.Text = "Planner";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Dock = DockStyle.Top;
            label11.Font = new Font("Century Gothic", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(0, 0);
            label11.Name = "label11";
            label11.Padding = new Padding(33, 50, 0, 0);
            label11.Size = new Size(135, 97);
            label11.TabIndex = 6;
            label11.Text = "Petit";
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Dock = DockStyle.Right;
            panel3.Location = new Point(140, 0);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(134, 199);
            panel3.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(134, 199);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.AutoScroll = true;
            panel4.BackColor = Color.FromArgb(232, 239, 253);
            panel4.Controls.Add(panelContenido);
            panel4.Controls.Add(panel5);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(300, 0);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(1160, 786);
            panel4.TabIndex = 39;
            panel4.Paint += panel4_Paint;
            // 
            // panelContenido
            // 
            panelContenido.BackColor = Color.White;
            panelContenido.Controls.Add(label8);
            panelContenido.Controls.Add(panel8);
            panelContenido.Controls.Add(label2);
            panelContenido.Controls.Add(panel6);
            panelContenido.Controls.Add(label4);
            panelContenido.Controls.Add(dateEvent);
            panelContenido.Controls.Add(label6);
            panelContenido.Controls.Add(hourEvent);
            panelContenido.Controls.Add(label7);
            panelContenido.Controls.Add(panel11);
            panelContenido.Controls.Add(label3);
            panelContenido.Controls.Add(panel10);
            panelContenido.Controls.Add(label9);
            panelContenido.Controls.Add(panel9);
            panelContenido.Controls.Add(label1);
            panelContenido.Controls.Add(panel7);
            panelContenido.Controls.Add(button3);
            panelContenido.Controls.Add(button1);
            panelContenido.Location = new Point(200, 125);
            panelContenido.Margin = new Padding(3, 4, 3, 4);
            panelContenido.Name = "panelContenido";
            panelContenido.Size = new Size(700, 1200);
            panelContenido.TabIndex = 42;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label8.Location = new Point(51, 38);
            label8.Name = "label8";
            label8.Size = new Size(131, 23);
            label8.TabIndex = 38;
            label8.Text = "Event name:";
            label8.Click += label8_Click;
            // 
            // panel8
            // 
            panel8.BackColor = SystemColors.Window;
            panel8.BorderStyle = BorderStyle.FixedSingle;
            panel8.Controls.Add(nameLabel);
            panel8.Location = new Point(56, 75);
            panel8.Margin = new Padding(3, 4, 3, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(555, 62);
            panel8.TabIndex = 39;
            // 
            // nameLabel
            // 
            nameLabel.BorderStyle = BorderStyle.None;
            nameLabel.Font = new Font("Century Gothic", 10F);
            nameLabel.Location = new Point(14, 12);
            nameLabel.Margin = new Padding(3, 4, 3, 4);
            nameLabel.Multiline = true;
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(522, 38);
            nameLabel.TabIndex = 12;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label2.Location = new Point(51, 162);
            label2.Name = "label2";
            label2.Size = new Size(161, 23);
            label2.TabIndex = 42;
            label2.Text = "Number Phone:";
            // 
            // panel6
            // 
            panel6.BorderStyle = BorderStyle.FixedSingle;
            panel6.Controls.Add(numberPhoneEvent);
            panel6.Location = new Point(56, 200);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(555, 62);
            panel6.TabIndex = 43;
            // 
            // numberPhoneEvent
            // 
            numberPhoneEvent.BorderStyle = BorderStyle.None;
            numberPhoneEvent.Font = new Font("Century Gothic", 10F);
            numberPhoneEvent.Location = new Point(14, 14);
            numberPhoneEvent.Margin = new Padding(3, 4, 3, 4);
            numberPhoneEvent.Multiline = true;
            numberPhoneEvent.Name = "numberPhoneEvent";
            numberPhoneEvent.Size = new Size(522, 38);
            numberPhoneEvent.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label4.Location = new Point(51, 288);
            label4.Name = "label4";
            label4.Size = new Size(62, 23);
            label4.TabIndex = 41;
            label4.Text = "Date:";
            // 
            // dateEvent
            // 
            dateEvent.Font = new Font("Century Gothic", 10F);
            dateEvent.Location = new Point(56, 325);
            dateEvent.Margin = new Padding(3, 4, 3, 4);
            dateEvent.Name = "dateEvent";
            dateEvent.Size = new Size(555, 32);
            dateEvent.TabIndex = 40;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label6.Location = new Point(51, 388);
            label6.Name = "label6";
            label6.Size = new Size(61, 23);
            label6.TabIndex = 52;
            label6.Text = "Hour:";
            // 
            // hourEvent
            // 
            hourEvent.Font = new Font("Century Gothic", 10F);
            hourEvent.Format = DateTimePickerFormat.Time;
            hourEvent.Location = new Point(56, 425);
            hourEvent.Margin = new Padding(3, 4, 3, 4);
            hourEvent.Name = "hourEvent";
            hourEvent.ShowUpDown = true;
            hourEvent.Size = new Size(555, 32);
            hourEvent.TabIndex = 51;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label7.Location = new Point(51, 488);
            label7.Name = "label7";
            label7.Size = new Size(123, 23);
            label7.TabIndex = 47;
            label7.Text = "Type event:";
            // 
            // panel11
            // 
            panel11.BorderStyle = BorderStyle.FixedSingle;
            panel11.Controls.Add(typeEvent);
            panel11.Location = new Point(56, 525);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(555, 62);
            panel11.TabIndex = 48;
            // 
            // typeEvent
            // 
            typeEvent.BorderStyle = BorderStyle.None;
            typeEvent.Font = new Font("Century Gothic", 10F);
            typeEvent.Location = new Point(14, 14);
            typeEvent.Margin = new Padding(3, 4, 3, 4);
            typeEvent.Multiline = true;
            typeEvent.Name = "typeEvent";
            typeEvent.Size = new Size(522, 38);
            typeEvent.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label3.Location = new Point(51, 612);
            label3.Name = "label3";
            label3.Size = new Size(109, 23);
            label3.TabIndex = 45;
            label3.Text = "Ubication:";
            // 
            // panel10
            // 
            panel10.BorderStyle = BorderStyle.FixedSingle;
            panel10.Controls.Add(ubicationEvent);
            panel10.Location = new Point(56, 650);
            panel10.Margin = new Padding(3, 4, 3, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(555, 62);
            panel10.TabIndex = 50;
            // 
            // ubicationEvent
            // 
            ubicationEvent.BorderStyle = BorderStyle.None;
            ubicationEvent.Font = new Font("Century Gothic", 10F);
            ubicationEvent.Location = new Point(14, 14);
            ubicationEvent.Margin = new Padding(3, 4, 3, 4);
            ubicationEvent.Multiline = true;
            ubicationEvent.Name = "ubicationEvent";
            ubicationEvent.Size = new Size(522, 38);
            ubicationEvent.TabIndex = 12;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label9.Location = new Point(51, 738);
            label9.Name = "label9";
            label9.Size = new Size(125, 23);
            label9.TabIndex = 53;
            label9.Text = "Description:";
            // 
            // panel9
            // 
            panel9.BorderStyle = BorderStyle.FixedSingle;
            panel9.Controls.Add(descriptionLabel);
            panel9.Location = new Point(56, 775);
            panel9.Margin = new Padding(3, 4, 3, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(555, 187);
            panel9.TabIndex = 54;
            // 
            // descriptionLabel
            // 
            descriptionLabel.BorderStyle = BorderStyle.None;
            descriptionLabel.Font = new Font("Century Gothic", 10F);
            descriptionLabel.Location = new Point(14, 16);
            descriptionLabel.Margin = new Padding(3, 4, 3, 4);
            descriptionLabel.Multiline = true;
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new Size(522, 150);
            descriptionLabel.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            label1.Location = new Point(51, 988);
            label1.Name = "label1";
            label1.Size = new Size(93, 23);
            label1.TabIndex = 44;
            label1.Text = "Amount:";
            // 
            // panel7
            // 
            panel7.BorderStyle = BorderStyle.FixedSingle;
            panel7.Controls.Add(montoEvent);
            panel7.Location = new Point(56, 1025);
            panel7.Margin = new Padding(3, 4, 3, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(259, 54);
            panel7.TabIndex = 45;
            // 
            // montoEvent
            // 
            montoEvent.BackColor = Color.White;
            montoEvent.BorderStyle = BorderStyle.None;
            montoEvent.Font = new Font("Century Gothic", 10F);
            montoEvent.Location = new Point(14, 8);
            montoEvent.Margin = new Padding(3, 4, 3, 4);
            montoEvent.Multiline = true;
            montoEvent.Name = "montoEvent";
            montoEvent.ReadOnly = true;
            montoEvent.Size = new Size(231, 38);
            montoEvent.TabIndex = 12;
            // 
            // button3
            // 
            button3.BackColor = Color.Teal;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(337, 1026);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(274, 55);
            button3.TabIndex = 46;
            button3.Text = "Make a quote";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(12, 67, 122);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(56, 1107);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(555, 60);
            button1.TabIndex = 46;
            button1.Text = "Save";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(label5);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(1134, 96);
            panel5.TabIndex = 40;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Top;
            label5.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label5.ForeColor = Color.FromArgb(12, 67, 122);
            label5.Location = new Point(0, 0);
            label5.Name = "label5";
            label5.Padding = new Padding(50, 24, 0, 0);
            label5.Size = new Size(374, 71);
            label5.TabIndex = 10;
            label5.Text = "Schedule event";
            // 
            // agendarEvento
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel4);
            Controls.Add(panel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "agendarEvento";
            Size = new Size(1460, 786);
            Load += agendarEvento_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panelContenido.ResumeLayout(false);
            panelContenido.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Profile;
        private System.Windows.Forms.Button Agendar;
        private System.Windows.Forms.Button Calendario;
        private System.Windows.Forms.Button Catalogo; // NUEVA VARIABLE
        private System.Windows.Forms.Button Inventario;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.TextBox ubicationEvent;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox typeEvent;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox descriptionLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker hourEvent;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateEvent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox numberPhoneEvent;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox montoEvent;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox nameLabel;
    }
}