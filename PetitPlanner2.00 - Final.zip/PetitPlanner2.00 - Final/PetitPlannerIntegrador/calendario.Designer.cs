﻿namespace PetitPlannerIntegrador
{
    partial class calendario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            panel1 = new Panel();
            Profile = new Button();
            agendar = new Button();
            btnCalendario = new Button();
            inventary = new Button();
            CatalogButton = new Button();
            homePage = new Button();
            panel2 = new Panel();
            label10 = new Label();
            label11 = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            panelContenido = new Panel();
            eventosDataGridView = new DataGridView();
            panel5 = new Panel();
            labelTitulo = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panelContenido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)eventosDataGridView).BeginInit();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.FromArgb(12, 67, 122);
            panel1.Controls.Add(Profile);
            panel1.Controls.Add(agendar);
            panel1.Controls.Add(btnCalendario);
            panel1.Controls.Add(inventary);
            panel1.Controls.Add(CatalogButton);
            panel1.Controls.Add(homePage);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 1024);
            panel1.TabIndex = 38;
            // 
            // Profile
            // 
            Profile.BackColor = Color.FromArgb(12, 67, 122);
            Profile.Dock = DockStyle.Top;
            Profile.FlatAppearance.BorderSize = 0;
            Profile.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Profile.FlatStyle = FlatStyle.Flat;
            Profile.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Profile.ForeColor = Color.White;
            Profile.Image = Properties.Resources.perfil_blanco_27;
            Profile.Location = new Point(0, 819);
            Profile.Name = "Profile";
            Profile.Padding = new Padding(22, 0, 0, 0);
            Profile.Size = new Size(300, 124);
            Profile.TabIndex = 17;
            Profile.Text = "     Profile";
            Profile.TextImageRelation = TextImageRelation.ImageBeforeText;
            Profile.UseVisualStyleBackColor = false;
            Profile.Click += Profile_Click;
            // 
            // agendar
            // 
            agendar.BackColor = Color.FromArgb(12, 67, 122);
            agendar.Dock = DockStyle.Top;
            agendar.FlatAppearance.BorderSize = 0;
            agendar.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            agendar.FlatStyle = FlatStyle.Flat;
            agendar.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            agendar.ForeColor = Color.White;
            agendar.Image = Properties.Resources.agendar_blanco_27;
            agendar.Location = new Point(0, 695);
            agendar.Name = "agendar";
            agendar.Padding = new Padding(30, 0, 0, 0);
            agendar.Size = new Size(300, 124);
            agendar.TabIndex = 16;
            agendar.Text = "   Schedule";
            agendar.TextImageRelation = TextImageRelation.ImageBeforeText;
            agendar.UseVisualStyleBackColor = false;
            agendar.Click += agendar_Click;
            // 
            // btnCalendario
            // 
            btnCalendario.BackColor = Color.FromArgb(232, 239, 253);
            btnCalendario.Dock = DockStyle.Top;
            btnCalendario.FlatAppearance.BorderSize = 0;
            btnCalendario.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            btnCalendario.FlatStyle = FlatStyle.Flat;
            btnCalendario.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            btnCalendario.ForeColor = Color.FromArgb(12, 67, 122);
            btnCalendario.Image = Properties.Resources.calendario_azul_27;
            btnCalendario.Location = new Point(0, 571);
            btnCalendario.Name = "btnCalendario";
            btnCalendario.Padding = new Padding(25, 0, 0, 0);
            btnCalendario.Size = new Size(300, 124);
            btnCalendario.TabIndex = 15;
            btnCalendario.Text = "   Calender";
            btnCalendario.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCalendario.UseVisualStyleBackColor = false;
            // 
            // inventary
            // 
            inventary.BackColor = Color.FromArgb(12, 67, 122);
            inventary.Dock = DockStyle.Top;
            inventary.FlatAppearance.BorderSize = 0;
            inventary.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            inventary.FlatStyle = FlatStyle.Flat;
            inventary.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            inventary.ForeColor = Color.White;
            inventary.Image = Properties.Resources.inventario_blanca_27;
            inventary.Location = new Point(0, 447);
            inventary.Name = "inventary";
            inventary.Padding = new Padding(28, 0, 0, 0);
            inventary.Size = new Size(300, 124);
            inventary.TabIndex = 14;
            inventary.Text = "   Inventory";
            inventary.TextImageRelation = TextImageRelation.ImageBeforeText;
            inventary.UseVisualStyleBackColor = false;
            inventary.Click += inventary_Click;
            // 
            // CatalogButton
            // 
            CatalogButton.BackColor = Color.FromArgb(12, 67, 122);
            CatalogButton.Dock = DockStyle.Top;
            CatalogButton.FlatAppearance.BorderSize = 0;
            CatalogButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            CatalogButton.FlatStyle = FlatStyle.Flat;
            CatalogButton.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            CatalogButton.ForeColor = Color.White;
            CatalogButton.Image = Properties.Resources.catalogo_blanco_27;
            CatalogButton.Location = new Point(0, 323);
            CatalogButton.Name = "CatalogButton";
            CatalogButton.Padding = new Padding(28, 0, 0, 0);
            CatalogButton.Size = new Size(300, 124);
            CatalogButton.TabIndex = 18;
            CatalogButton.Text = "    Catalog";
            CatalogButton.TextImageRelation = TextImageRelation.ImageBeforeText;
            CatalogButton.UseVisualStyleBackColor = false;
            CatalogButton.Click += CatalogButton_Click;
            // 
            // homePage
            // 
            homePage.BackColor = Color.FromArgb(12, 67, 122);
            homePage.Dock = DockStyle.Top;
            homePage.FlatAppearance.BorderSize = 0;
            homePage.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            homePage.FlatStyle = FlatStyle.Flat;
            homePage.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            homePage.ForeColor = Color.White;
            homePage.Image = Properties.Resources.casa_blanca_27;
            homePage.Location = new Point(0, 199);
            homePage.Name = "homePage";
            homePage.Padding = new Padding(22, 0, 0, 0);
            homePage.Size = new Size(300, 124);
            homePage.TabIndex = 13;
            homePage.Text = "    Home";
            homePage.TextImageRelation = TextImageRelation.ImageBeforeText;
            homePage.UseVisualStyleBackColor = false;
            homePage.Click += homePage_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(label10);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(panel3);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(300, 199);
            panel2.TabIndex = 0;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label10.ForeColor = Color.White;
            label10.Location = new Point(24, 87);
            label10.Name = "label10";
            label10.Size = new Size(165, 47);
            label10.TabIndex = 7;
            label10.Text = "Planner";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Dock = DockStyle.Top;
            label11.Font = new Font("Century Gothic", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(0, 0);
            label11.Name = "label11";
            label11.Padding = new Padding(30, 40, 0, 0);
            label11.Size = new Size(132, 87);
            label11.TabIndex = 6;
            label11.Text = "Petit";
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Dock = DockStyle.Right;
            panel3.Location = new Point(179, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(121, 199);
            panel3.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(121, 199);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.AutoScroll = true;
            panel4.BackColor = Color.FromArgb(232, 239, 253);
            panel4.Controls.Add(panelContenido);
            panel4.Controls.Add(panel5);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(300, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(1598, 1024);
            panel4.TabIndex = 39;
            // 
            // panelContenido
            // 
            panelContenido.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelContenido.BackColor = Color.White;
            panelContenido.Controls.Add(eventosDataGridView);
            panelContenido.Location = new Point(50, 130);
            panelContenido.Name = "panelContenido";
            panelContenido.Size = new Size(1498, 850);
            panelContenido.TabIndex = 41;
            // 
            // eventosDataGridView
            // 
            eventosDataGridView.AllowUserToAddRows = false;
            eventosDataGridView.AllowUserToResizeColumns = false;
            eventosDataGridView.AllowUserToResizeRows = false;
            eventosDataGridView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            eventosDataGridView.BackgroundColor = Color.White;
            eventosDataGridView.BorderStyle = BorderStyle.None;
            eventosDataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 10F);
            dataGridViewCellStyle1.ForeColor = Color.White;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            eventosDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            eventosDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            eventosDataGridView.EnableHeadersVisualStyles = false;
            eventosDataGridView.GridColor = Color.LightGray;
            eventosDataGridView.Location = new Point(20, 20);
            eventosDataGridView.Name = "eventosDataGridView";
            eventosDataGridView.RowHeadersVisible = false;
            eventosDataGridView.RowHeadersWidth = 62;
            eventosDataGridView.Size = new Size(1458, 810);
            eventosDataGridView.TabIndex = 18;
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(labelTitulo);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(1598, 100);
            panel5.TabIndex = 40;
            // 
            // labelTitulo
            // 
            labelTitulo.AutoSize = true;
            labelTitulo.Dock = DockStyle.Top;
            labelTitulo.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            labelTitulo.ForeColor = Color.FromArgb(12, 67, 122);
            labelTitulo.Location = new Point(0, 0);
            labelTitulo.Name = "labelTitulo";
            labelTitulo.Padding = new Padding(50, 24, 0, 0);
            labelTitulo.Size = new Size(252, 71);
            labelTitulo.TabIndex = 10;
            labelTitulo.Text = "Calender";
            // 
            // calendario
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel4);
            Controls.Add(panel1);
            Name = "calendario";
            Size = new Size(1898, 1024);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panelContenido.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)eventosDataGridView).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Profile;
        private System.Windows.Forms.Button agendar;
        private System.Windows.Forms.Button btnCalendario;
        private System.Windows.Forms.Button CatalogButton;
        private System.Windows.Forms.Button inventary;
        private System.Windows.Forms.Button homePage;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label labelTitulo;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.DataGridView eventosDataGridView;
    }
}