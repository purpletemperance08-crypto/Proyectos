﻿using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    // Cambiamos la herencia de UserControl a Form
    public partial class realizarCotizacion : Form
    {
        private List<ItemCotizacionModel> CarritoCotizacion = new List<ItemCotizacionModel>();
        private readonly ProductRepositorie productRepo = new ProductRepositorie();
        private string IdInventorio;

        // NOTA: El evento FinalizarCotizacion ya no es necesario para comunicación
        // si este es un formulario independiente que se cierra,
        // pero lo mantengo por si se usa para notificar a un formulario padre.
        public event EventHandler FinalizarCotizacion;

        public realizarCotizacion()
        {
            InitializeComponent();

            // Configuración inicial de DataGridViews
            dgvCarrito.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvInventario.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            this.dgvInventario.DataBindingComplete += dgvInventario_DataBindingComplete;
            CargarInventario();
            ConfigurarDataGridViews();

            // Asignar handlers de eventos (que faltaban en tu código, excepto el del constructor)
            btnAnadir.Click += BtnAnadir_Click;
            dgvCarrito.CellClick += DgvCarrito_CellClick;
            dgvCarrito.CellEndEdit += DgvCarrito_CellEndEdit; // Aseguramos que la edición funcione
            finalizarCoti.Click += finalizarCoti_Click; // Asumo que 'finalizarCoti' es el nombre del botón de tu diseñador.

            // NOTA: Para un Form, puedes configurar el título aquí
            this.Text = "Realizar Cotización";
        }


        private void dgvInventario_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            DataGridView dgv = (DataGridView)sender;

            // --- Configurar Visibilidad y Encabezados ---

            // 1. Ocultar IdInventario
            if (dgv.Columns.Contains("IdInventario"))
            {
                dgv.Columns["IdInventario"].Visible = false;
            }

            // 2. Ocultar IdProducto
            if (dgv.Columns.Contains("IdProducto"))
            {
                dgv.Columns["IdProducto"].Visible = false;
            }

            // 3. Ocultar Description
            if (dgv.Columns.Contains("Description"))
            {
                dgv.Columns["Description"].Visible = false;
            }

            // 4. Configurar Name (Hacer visible y poner encabezado)
            if (dgv.Columns.Contains("Name"))
            {
                dgv.Columns["Name"].Visible = true;
                dgv.Columns["Name"].HeaderText = "Producto";
                // Ajustar el ancho de la columna si es necesario
                dgv.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            // 5. Configurar Price (Hacer visible, poner encabezado y aplicar formato)
            if (dgv.Columns.Contains("Price"))
            {
                dgv.Columns["Price"].Visible = true;
                dgv.Columns["Price"].HeaderText = "Precio";
                // Formato de moneda para Price
                dgv.Columns["Price"].DefaultCellStyle.Format = "C2";
                dgv.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
        }

        private void ConfigurarDataGridViews()
        {
            // Aseguramos la generación automática de columnas para que el evento 
            // DataBindingComplete pueda referenciarlas y ocultarlas.
            this.dgvInventario.AutoGenerateColumns = true;

            // Configurar dgvCarrito para mostrar las columnas de ItemCotizacion
            this.dgvCarrito.AutoGenerateColumns = false;

            // Eliminar columnas existentes para evitar duplicados si se llama más de una vez
            dgvCarrito.Columns.Clear();

            // Columna Nombre
            dgvCarrito.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Producto",
                DataPropertyName = "Name",
                Name = "colName",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                ReadOnly = true
            });
            // Columna Cantidad (hacerla editable)
            dgvCarrito.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Cantidad",
                DataPropertyName = "Cantidad",
                Name = "colCantidad",
                Width = 80
            });
            // Columna Precio Unitario
            dgvCarrito.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Precio Unitario",
                DataPropertyName = "PrecioUnitario",
                Name = "colPrecio",
                ReadOnly = true
            });
            // Columna Subtotal
            dgvCarrito.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Subtotal",
                DataPropertyName = "Subtotal",
                Name = "colSubtotal",
                ReadOnly = true
            });
            // Columna Botón Eliminar
            dgvCarrito.Columns.Add(new DataGridViewButtonColumn()
            {
                HeaderText = "Acción",
                Text = "Eliminar",
                UseColumnTextForButtonValue = true,
                Name = "colEliminar",
                Width = 70
            });

            // Aplicar formato de moneda inicial
            ConfigurarColumnasCarrito();
        }

        public void CargarInventario()
        {
            try
            {
                string idInventory = SessionManager.CurrentIdInventory;
                List<productModel> productos = productRepo.GetProductsByInventoryId(idInventory);

                dgvInventario.DataSource = productos;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar el inventario: " + ex.Message, "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EnlazarYRecalcularCarrito()
        {
            // Crear una nueva lista para forzar la actualización del DataBinding
            var listaTemporal = new List<ItemCotizacionModel>(CarritoCotizacion);

            dgvCarrito.DataSource = null;
            dgvCarrito.DataSource = listaTemporal;

            // Asegurar que las columnas tengan el formato correcto después de reenlazar
            ConfigurarColumnasCarrito();

            RecalcularTotales();
        }


        private void BtnAnadir_Click(object sender, EventArgs e)
        {
            if (dgvInventario.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, seleccione un producto del inventario.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la entrada sea un número entero positivo
            if (!int.TryParse(txtCantidad.Text, out int cantidad) || cantidad <= 0)
            {
                MessageBox.Show("Ingrese una cantidad válida y mayor a cero.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener el producto seleccionado
            productModel productoSeleccionado = (productModel)dgvInventario.SelectedRows[0].DataBoundItem;

            // Buscar si ya existe en el carrito
            ItemCotizacionModel itemExistente = CarritoCotizacion.FirstOrDefault(i => i.IdProducto == productoSeleccionado.IdProducto);

            if (itemExistente != null)
            {
                itemExistente.Cantidad += cantidad;
            }
            else
            {
                // Crear y añadir nuevo ítem
                ItemCotizacionModel nuevoItem = new ItemCotizacionModel(productoSeleccionado, cantidad);
                CarritoCotizacion.Add(nuevoItem);
            }

            EnlazarYRecalcularCarrito();
            txtCantidad.Clear();
        }

        private void DgvCarrito_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verificar si el clic fue en la columna "Eliminar"
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvCarrito.Columns["colEliminar"].Index)
            {
                // Usamos BeginInvoke para evitar problemas de reentrada si el clic
                // ocurre durante otra operación del DataGridView.
                BeginInvoke(new Action(() => EliminarItemDelCarrito(e.RowIndex)));
            }
        }

        private void EliminarItemDelCarrito(int rowIndex)
        {
            try
            {
                if (rowIndex < 0 || rowIndex >= CarritoCotizacion.Count) return;

                // Como dgvCarrito.DataSource es CarritoCotizacion (aunque forzado con lista temporal),
                // podemos acceder directamente al índice de la lista.
                CarritoCotizacion.RemoveAt(rowIndex);

                EnlazarYRecalcularCarrito();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el producto: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // El método ActualizarCarritoSeguro se puede simplificar o fusionar con EnlazarYRecalcularCarrito
        // si se utiliza el enfoque de re-enlazar (datasource = null, datasource = list).
        // Lo mantengo aquí como llamada a EnlazarYRecalcularCarrito para mantener la lógica.
        private void ActualizarCarritoSeguro()
        {
            EnlazarYRecalcularCarrito();
        }

        private void ConfigurarColumnasCarrito()
        {
            foreach (DataGridViewColumn col in dgvCarrito.Columns)
            {
                if (col.Name == "colPrecio" || col.Name == "colSubtotal")
                {
                    col.DefaultCellStyle.Format = "C2";
                    col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (col.Name == "colName")
                {
                    col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
            }
        }

        private void RecalcularTotales()
        {
            // Asegurarse de que Subtotal se calcula dentro de ItemCotizacionModel o recalcular aquí.
            // Asumiendo que ItemCotizacionModel ya calcula Subtotal al modificar Cantidad.

            decimal montoTotal = CarritoCotizacion.Sum(item => item.Subtotal);
            int cantidadTotal = CarritoCotizacion.Sum(item => item.Cantidad);

            lblTotalCantidad.Text = cantidadTotal.ToString();
            lblMontoFinal.Text = montoTotal.ToString("C2");
            SessionManager.MontoCotizacionTemporal = montoTotal;
        }

        private void DgvCarrito_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Validar si la edición fue en la columna Cantidad
            if (e.ColumnIndex == dgvCarrito.Columns["colCantidad"].Index)
            {
                DataGridViewRow row = dgvCarrito.Rows[e.RowIndex];
                ItemCotizacionModel itemEditado = (ItemCotizacionModel)row.DataBoundItem;

                // Intentar obtener el nuevo valor de la celda editada
                object cellValue = row.Cells[e.ColumnIndex].Value;

                if (cellValue != null && int.TryParse(cellValue.ToString(), out int nuevaCantidad) && nuevaCantidad > 0)
                {
                    itemEditado.Cantidad = nuevaCantidad; // Esto recalcula Subtotal dentro del modelo
                }
                else
                {
                    MessageBox.Show("Cantidad no válida. Ingrese un número mayor a cero.", "Error de entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // Reestablecer el valor anterior si la entrada es inválida (Opcional, pero buena práctica)
                    row.Cells[e.ColumnIndex].Value = itemEditado.Cantidad;
                }

                EnlazarYRecalcularCarrito();
            }
        }

        private void finalizarCoti_Click(object sender, EventArgs e)
        {
            // Guarda el monto final en la sesión o base de datos antes de notificar/cerrar
            SessionManager.MontoCotizacionTemporal = CarritoCotizacion.Sum(item => item.Subtotal);

            // Si el formulario padre necesita ser notificado, invoca el evento.
            FinalizarCotizacion?.Invoke(this, EventArgs.Empty);

            // Cierra el formulario
            this.Close();
        }
    }
}