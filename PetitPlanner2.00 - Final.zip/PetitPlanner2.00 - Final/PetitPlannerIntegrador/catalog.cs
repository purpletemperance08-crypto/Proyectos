﻿using PetitPlannerIntegrador.Models; // ⭐ Esta línea es la CLAVE
using PetitPlannerIntegrador.Repositories;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Linq; 

namespace PetitPlannerIntegrador
{
    public partial class catalog : UserControl
    {
        // 1. EVENTOS YA EXISTENTES
        public event EventHandler IrAHomePage;
        public event EventHandler IrAAñadirCatalog;

        // 🛑 1. EVENTOS DE NAVEGACIÓN AÑADIDOS
        public event EventHandler IrAInventoryPage;
        public event EventHandler IrACalendarPage;
        public event EventHandler IrAAgendarPage;
        public event EventHandler IrAProfilePage;
        public event EventHandler IrAInventory;

        public catalog()
        {
            InitializeComponent();

            catalogGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            catalogGridView.ReadOnly = true;
            catalogGridView.AllowUserToAddRows = false; // Añadido para consistencia

            cargarDatosCatalogo();
        }

        private void cargarDatosCatalogo()
        {
            string idInventario = SessionManager.CurrentIdInventory;

            if (string.IsNullOrEmpty(idInventario))
            {
                catalogGridView.DataSource = null;
                MessageBox.Show("Error: ID de Inventario no cargado.", "Error de Sesión",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                CatalogRepositorie repo = new CatalogRepositorie();
                List<InventarioItem> itemsCatalogo = repo.GetCatalogItemsByInventoryId(idInventario);

                // 🔑 CÓDIGO CLAVE: Ordenar la lista por Stock ASCENDENTE (Menor stock primero)
                if (itemsCatalogo != null)
                {
                    // Usa OrderBy para ordenar por la propiedad 'stock' de menor a mayor
                    itemsCatalogo = itemsCatalogo.OrderBy(item => item.stock).ToList();
                }

                catalogGridView.DataSource = itemsCatalogo;

                // 4. Aplicar Configuración de Columnas
                // Ocultar las columnas que contienen IDs internos
                if (catalogGridView.Columns.Contains("id_inventory"))
                {
                    catalogGridView.Columns["id_inventory"].Visible = false;
                }

                if (catalogGridView.Columns.Contains("id_catalog"))
                {
                    catalogGridView.Columns["id_catalog"].Visible = false;
                }

                // Opcional: Renombrar o ajustar el ancho de otras columnas para mejor visualización
                if (catalogGridView.Columns.Contains("name"))
                {
                    catalogGridView.Columns["name"].HeaderText = "Nombre";
                    catalogGridView.Columns["name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                if (catalogGridView.Columns.Contains("description"))
                {
                    catalogGridView.Columns["description"].HeaderText = "Descripción";
                }
                if (catalogGridView.Columns.Contains("stock"))
                {
                    catalogGridView.Columns["stock"].HeaderText = "Stock";
                }

                // Deshabilitar el ordenamiento de columna para mantener el orden por stock bajo
                foreach (DataGridViewColumn col in catalogGridView.Columns)
                {
                    col.SortMode = DataGridViewColumnSortMode.NotSortable;
                }
            }
            catch (Exception ex)
            {
                // Manejar errores de conexión o repositorio
                MessageBox.Show($"Error al cargar el catálogo: {ex.Message}", "Error de Base de Datos",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
                catalogGridView.DataSource = null;
            }
        }

        // 5. Método para refrescar los datos desde otro formulario
        public void RefrescarDatos() => cargarDatosCatalogo();


        // 🛑 MANEJADORES DE EVENTOS DE NAVEGACIÓN

        // El botón "Home" usa el método IrAHomePage
        private void Home_Click(object sender, EventArgs e)
        {
            IrAHomePage?.Invoke(this, EventArgs.Empty);
        }

        // El botón "Inventario" usa el método IrAInventoryPage
        private void Inventario_Click(object sender, EventArgs e)
        {
            IrAInventoryPage?.Invoke(this, EventArgs.Empty);
        }

        // El botón "Calendario" usa el método IrACalendarPage
        private void calendario_Click(object sender, EventArgs e)
        {
            IrACalendarPage?.Invoke(this, EventArgs.Empty);
        }

        // El botón "Agendar" usa el método IrAAgendarPage
        private void agendar_Click(object sender, EventArgs e)
        {
            IrAAgendarPage?.Invoke(this, EventArgs.Empty);
        }

        // El botón "Profile" usa el método IrAProfilePage
        private void profile_Click(object sender, EventArgs e)
        {
            IrAProfilePage?.Invoke(this, EventArgs.Empty);
        }


        // El botón "Añadir/Gestionar Catálogo"
        private void añadirCatalog_Click(object sender, EventArgs e)
        {
            IrAAñadirCatalog?.Invoke(this, EventArgs.Empty);
        }

    }
}