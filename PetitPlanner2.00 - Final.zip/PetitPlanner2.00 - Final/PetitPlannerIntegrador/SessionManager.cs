﻿namespace PetitPlannerIntegrador
{
        public static class SessionManager
        {
            // Ambos IDs definidos como STRING para evitar conversiones
            public static string CurrentUserId { get; private set; }
            public static string CurrentIdBusiness { get; private set; } 
            public static string CurrentIdInventory { get; private set; } 
            public static string CurrentIdCalender { get; private set; }
            public static string CurrentIdEvent { get; private set; }
            public static string CurrentIdCatalog { get; private set; }
        public static decimal MontoCotizacionTemporal { get; set; } = 0m;


            public static void StartSession(string userId)
            {
                CurrentUserId = userId;
            }
            public static void setIdBussines(string idBussines)
            {
                CurrentIdBusiness = idBussines;
            }
            public static void setIdInventory(string idInventory)
            {
                CurrentIdInventory = idInventory;

            }
            public static void setIdCalender(string IdCalender)
            {
                CurrentIdCalender = IdCalender;
            }
            public static void setIdEvent(string IdEvent)
            {
                CurrentIdEvent = IdEvent;

            }

        public static void setIdCatalog(string IdCatalog)
        {
            CurrentIdCatalog = IdCatalog;

        }
        // Cierra la sesión
        public static void EndSession()
        {
            CurrentUserId = null;
            CurrentIdBusiness = null;
            CurrentIdInventory = null;
            CurrentIdCalender = null;
            CurrentIdEvent = null;
            CurrentIdCatalog = null;
        }
            }
        }
    