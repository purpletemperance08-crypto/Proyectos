﻿namespace PetitPlannerIntegrador
{
    partial class PagarEvento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textTotal = new TextBox();
            textInvestment = new TextBox();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // textTotal
            // 
            textTotal.Location = new Point(108, 130);
            textTotal.Name = "textTotal";
            textTotal.Size = new Size(212, 31);
            textTotal.TabIndex = 0;
            // 
            // textInvestment
            // 
            textInvestment.Location = new Point(108, 209);
            textInvestment.Name = "textInvestment";
            textInvestment.Size = new Size(212, 31);
            textInvestment.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(152, 264);
            button1.Name = "button1";
            button1.Size = new Size(123, 34);
            button1.TabIndex = 2;
            button1.Text = "Payment";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(108, 102);
            label1.Name = "label1";
            label1.Size = new Size(49, 25);
            label1.TabIndex = 3;
            label1.Text = "Total";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(108, 181);
            label2.Name = "label2";
            label2.Size = new Size(100, 25);
            label2.TabIndex = 4;
            label2.Text = "Investment";
            // 
            // PagarEvento
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(433, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(textInvestment);
            Controls.Add(textTotal);
            Name = "PagarEvento";
            Text = "PagarEvento";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textTotal;
        private TextBox textInvestment;
        private Button button1;
        private Label label1;
        private Label label2;
    }
}