﻿namespace PetitPlannerIntegrador
{
    partial class homePageControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            catalogo = new Button();
            calendario = new Button();
            agendar = new Button();
            profile = new Button();
            panel1 = new Panel();
            Inventario = new Button();
            Home = new Button();
            panel2 = new Panel();
            label3 = new Label();
            label1 = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            panel5 = new Panel();
            label2 = new Label();
            chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            panel6 = new Panel();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label4 = new Label();
            label5 = new Label();
            mySqlCommand1 = new MySqlConnector.MySqlCommand();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chart1).BeginInit();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // catalogo
            // 
            catalogo.BackColor = Color.FromArgb(12, 67, 122);
            catalogo.Dock = DockStyle.Top;
            catalogo.FlatAppearance.BorderSize = 0;
            catalogo.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            catalogo.FlatStyle = FlatStyle.Flat;
            catalogo.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            catalogo.ForeColor = Color.White;
            catalogo.Image = Properties.Resources.catalogo_blanco_27;
            catalogo.Location = new Point(0, 323);
            catalogo.Name = "catalogo";
            catalogo.Padding = new Padding(28, 0, 0, 0);
            catalogo.Size = new Size(274, 124);
            catalogo.TabIndex = 1;
            catalogo.Text = "  Catalog";
            catalogo.TextImageRelation = TextImageRelation.ImageBeforeText;
            catalogo.UseVisualStyleBackColor = false;
            catalogo.Click += catalogo_Click;
            // 
            // calendario
            // 
            calendario.BackColor = Color.FromArgb(12, 67, 122);
            calendario.Dock = DockStyle.Top;
            calendario.FlatAppearance.BorderSize = 0;
            calendario.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            calendario.FlatStyle = FlatStyle.Flat;
            calendario.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            calendario.ForeColor = Color.White;
            calendario.Image = Properties.Resources.calendario_blanco_27;
            calendario.Location = new Point(0, 571);
            calendario.Name = "calendario";
            calendario.Padding = new Padding(32, 0, 0, 0);
            calendario.Size = new Size(274, 124);
            calendario.TabIndex = 3;
            calendario.Text = "  Calender";
            calendario.TextImageRelation = TextImageRelation.ImageBeforeText;
            calendario.UseVisualStyleBackColor = false;
            calendario.Click += button2_Click;
            // 
            // agendar
            // 
            agendar.BackColor = Color.FromArgb(12, 67, 122);
            agendar.Dock = DockStyle.Top;
            agendar.FlatAppearance.BorderSize = 0;
            agendar.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            agendar.FlatStyle = FlatStyle.Flat;
            agendar.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            agendar.ForeColor = Color.White;
            agendar.Image = Properties.Resources.agendar_blanco_27;
            agendar.Location = new Point(0, 695);
            agendar.Name = "agendar";
            agendar.Padding = new Padding(30, 0, 0, 0);
            agendar.Size = new Size(274, 124);
            agendar.TabIndex = 4;
            agendar.Text = " Schedule";
            agendar.TextImageRelation = TextImageRelation.ImageBeforeText;
            agendar.UseVisualStyleBackColor = false;
            agendar.Click += button3_Click;
            // 
            // profile
            // 
            profile.BackColor = Color.FromArgb(12, 67, 122);
            profile.Dock = DockStyle.Top;
            profile.FlatAppearance.BorderSize = 0;
            profile.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            profile.FlatStyle = FlatStyle.Flat;
            profile.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            profile.ForeColor = Color.White;
            profile.Image = Properties.Resources.perfil_blanco_27;
            profile.Location = new Point(0, 819);
            profile.Name = "profile";
            profile.Padding = new Padding(22, 0, 0, 0);
            profile.Size = new Size(274, 124);
            profile.TabIndex = 5;
            profile.Text = "  Profile";
            profile.TextImageRelation = TextImageRelation.ImageBeforeText;
            profile.UseVisualStyleBackColor = false;
            profile.Click += button4_Click;
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.FromArgb(12, 67, 122);
            panel1.Controls.Add(profile);
            panel1.Controls.Add(agendar);
            panel1.Controls.Add(calendario);
            panel1.Controls.Add(Inventario);
            panel1.Controls.Add(catalogo);
            panel1.Controls.Add(Home);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 652);
            panel1.TabIndex = 5;
            // 
            // Inventario
            // 
            Inventario.BackColor = Color.FromArgb(12, 67, 122);
            Inventario.Dock = DockStyle.Top;
            Inventario.FlatAppearance.BorderSize = 0;
            Inventario.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Inventario.FlatStyle = FlatStyle.Flat;
            Inventario.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Inventario.ForeColor = Color.White;
            Inventario.Image = Properties.Resources.inventario_blanca_27;
            Inventario.Location = new Point(0, 447);
            Inventario.Name = "Inventario";
            Inventario.Padding = new Padding(22, 0, 0, 0);
            Inventario.Size = new Size(274, 124);
            Inventario.TabIndex = 2;
            Inventario.Text = "  Inventory";
            Inventario.TextImageRelation = TextImageRelation.ImageBeforeText;
            Inventario.UseVisualStyleBackColor = false;
            Inventario.Click += button1_Click;
            // 
            // Home
            // 
            Home.BackColor = Color.FromArgb(232, 239, 253);
            Home.Dock = DockStyle.Top;
            Home.FlatAppearance.BorderSize = 0;
            Home.FlatStyle = FlatStyle.Flat;
            Home.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Home.ForeColor = Color.FromArgb(12, 67, 122);
            Home.Image = Properties.Resources.casa_azul2_27;
            Home.Location = new Point(0, 199);
            Home.Name = "Home";
            Home.Padding = new Padding(22, 0, 0, 0);
            Home.Size = new Size(274, 124);
            Home.TabIndex = 0;
            Home.Text = "  Home";
            Home.TextImageRelation = TextImageRelation.ImageBeforeText;
            Home.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(panel3);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(274, 199);
            panel2.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(24, 87);
            label3.Name = "label3";
            label3.Size = new Size(165, 47);
            label3.TabIndex = 7;
            label3.Text = "Planner";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Century Gothic", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Padding = new Padding(30, 40, 0, 0);
            label1.Size = new Size(132, 87);
            label1.TabIndex = 6;
            label1.Text = "Petit";
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Dock = DockStyle.Right;
            panel3.Location = new Point(153, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(121, 199);
            panel3.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(121, 199);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(232, 239, 253);
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(chart1);
            panel4.Controls.Add(panel6);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(300, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(893, 652);
            panel4.TabIndex = 6;
            panel4.Paint += panel4_Paint;
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(label2);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(893, 96);
            panel5.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(12, 67, 122);
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Padding = new Padding(50, 24, 0, 0);
            label2.Size = new Size(187, 71);
            label2.TabIndex = 0;
            label2.Text = "Home";
            // 
            // chart1
            // 
            chart1.Anchor = AnchorStyles.None;
            chart1.BackColor = Color.Transparent;
            chart1.BorderlineColor = Color.Transparent;
            chartArea1.AxisX.LabelStyle.Font = new Font("Century Gothic", 8F);
            chartArea1.AxisX.LineColor = Color.DarkGray;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisY.LabelStyle.Font = new Font("Century Gothic", 8F);
            chartArea1.AxisY.LineColor = Color.DarkGray;
            chartArea1.AxisY.MajorGrid.LineColor = Color.Gainsboro;
            chartArea1.BackColor = Color.Transparent;
            chartArea1.BorderWidth = 0;
            chartArea1.Name = "ChartArea1";
            chart1.ChartAreas.Add(chartArea1);
            legend1.BackColor = Color.Transparent;
            legend1.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            legend1.ForeColor = Color.FromArgb(12, 67, 122);
            legend1.IsTextAutoFit = false;
            legend1.Name = "Legend1";
            chart1.Legends.Add(legend1);
            chart1.Location = new Point(111, 102);
            chart1.Name = "chart1";
            chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series1.BorderWidth = 3;
            series1.ChartArea = "ChartArea1";
            series1.Color = Color.FromArgb(86, 126, 156);
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            chart1.Series.Add(series1);
            chart1.Size = new Size(683, 461);
            chart1.TabIndex = 0;
            chart1.Text = "chart1";
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(label9);
            panel6.Controls.Add(label8);
            panel6.Controls.Add(label7);
            panel6.Controls.Add(label6);
            panel6.Controls.Add(label4);
            panel6.Controls.Add(label5);
            panel6.Dock = DockStyle.Bottom;
            panel6.Location = new Point(0, 529);
            panel6.Name = "panel6";
            panel6.Size = new Size(893, 123);
            panel6.TabIndex = 5;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.Location = new Point(545, 17);
            label9.Name = "label9";
            label9.Size = new Size(121, 25);
            label9.TabIndex = 7;
            label9.Text = "Total Earnings";
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.Location = new Point(357, 17);
            label8.Name = "label8";
            label8.Size = new Size(142, 25);
            label8.TabIndex = 6;
            label8.Text = "Total Investment";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Location = new Point(220, 17);
            label7.Name = "label7";
            label7.Size = new Size(90, 25);
            label7.TabIndex = 5;
            label7.Text = "Total Cost";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Location = new Point(578, 50);
            label6.Name = "label6";
            label6.Size = new Size(59, 25);
            label6.TabIndex = 4;
            label6.Text = "label6";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Location = new Point(234, 50);
            label4.Name = "label4";
            label4.Size = new Size(59, 25);
            label4.TabIndex = 2;
            label4.Text = "label4";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Location = new Point(399, 50);
            label5.Name = "label5";
            label5.Size = new Size(59, 25);
            label5.TabIndex = 3;
            label5.Text = "label5";
            // 
            // mySqlCommand1
            // 
            mySqlCommand1.CommandTimeout = 0;
            mySqlCommand1.Connection = null;
            mySqlCommand1.Transaction = null;
            mySqlCommand1.UpdatedRowSource = System.Data.UpdateRowSource.None;
            // 
            // homePageControl
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(panel4);
            Controls.Add(panel1);
            MinimumSize = new Size(890, 400);
            Name = "homePageControl";
            Size = new Size(1193, 652);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)chart1).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button catalogo;
        private Button calendario;
        private Button agendar;
        private Button profile;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label3;
        private Panel panel4;
        private Button Home;
        private Button Inventario;
        private MySqlConnector.MySqlCommand mySqlCommand1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private Panel panel5;
        private Label label2;
        private Label label6;
        private Label label5;
        private Label label4;
        private Panel panel6;
        private Label label9;
        private Label label8;
        private Label label7;
    }
}