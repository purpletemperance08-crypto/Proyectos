﻿using PetitPlannerIntegrador.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    public partial class FormEditarProducto : Form
    {
        public FormEditarProducto()
        {
            InitializeComponent();

        }
        private readonly string _idProducto;
        private ProductRepositorie _repo = new ProductRepositorie();

        public FormEditarProducto(string idProducto)
        {
            InitializeComponent();
            _idProducto = idProducto;
            this.Text = "Editar Producto: " + idProducto;
            CargarDatosProducto();
        }

        private void CargarDatosProducto()
        {
            if (string.IsNullOrEmpty(_idProducto))
            {
                MessageBox.Show("Error: ID de producto no válido para la edición.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            try
            {
                productModel producto = _repo.GetProductById(_idProducto);
                if (producto != null)
                {
                    textBoxName.Text = producto.Name;
                    textBoxDescription.Text = producto.Description;
                    textBoxPrice.Text = producto.Price.ToString();
                }
                else
                {
                    MessageBox.Show("No se pudieron cargar los datos del producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos: {ex.Message}", "Error de BD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click_2(object sender, EventArgs e)
        {
            string nuevoNombre = textBoxName.Text;
            string nuevaDescripcion = textBoxDescription.Text;
            string precioStr = textBoxPrice.Text;

            if (string.IsNullOrEmpty(nuevoNombre) || string.IsNullOrEmpty(nuevaDescripcion) || string.IsNullOrEmpty(precioStr))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(precioStr, out decimal nuevoPrecio) || nuevoPrecio <= 0)
            {
                MessageBox.Show("Por favor, ingrese un precio válido mayor a 0.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxPrice.Focus();
                return;
            }

            try
            {
                _repo.UpdateProduct(_idProducto, nuevoNombre, nuevaDescripcion, nuevoPrecio);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                // 4. Manejar errores del repositorio
                MessageBox.Show($"❌ Error al guardar cambios: {ex.Message}", "Error de Actualización", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

