﻿// calendario.cs
using MySqlConnector;
using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace PetitPlannerIntegrador
{
    public partial class calendario : UserControl
    {
        private readonly string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";

        // Variables para el evento actualmente seleccionado
        private string idCalender;
        private string idEvent;
        private string eventName;
        private string eventHour;
        private string eventDescription;
        private string dateEvent;

        // Nuevas variables para los detalles del evento
        private string eventUbication;
        private string eventNumberPhone;
        private string eventType;
        private decimal eventMonto;


        // Eventos de navegación
        public event EventHandler IrAInicio;
        public event EventHandler IrAInventario;
        public event EventHandler IrAAgendarEvento;
        public event EventHandler IrAProfile;
        public event EventHandler IrACatalog;



        public calendario()
        {
            InitializeComponent();

            // Deshabilita la fila de adición automática
            if (eventosDataGridView != null)
            {
                eventosDataGridView.AllowUserToAddRows = false;
            }

            // Cargar datos al iniciar
            RefrescarDatos();

            // Suscribir manejadores de eventos
            if (eventosDataGridView != null)
            {
                eventosDataGridView.SelectionChanged += eventosDataGridView_SelectionChanged;
                eventosDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

                // Suscripción al evento para detectar clics en los botones de columna
                eventosDataGridView.CellClick += eventosDataGridView_CellClick;

                // Suscripción para el formato de celda y botones
                eventosDataGridView.CellFormatting += eventosDataGridView_CellFormatting;

                // 🔑 CORRECCIÓN: Suscribir CellContentClick para manejar el clic en CheckBox y botones
                eventosDataGridView.CellContentClick += eventosDataGridView_CellContentClick;
            }
        }

        // --- MÉTODOS DE CARGA DE DATOS ---

        private void CargarDatosCalender()
        {
            CalenderRepositorie repo = new CalenderRepositorie();
            CalenderModel? usuarioActivo = repo.UserInformation();

            if (usuarioActivo == null || string.IsNullOrEmpty(usuarioActivo.idCalender))
            {
                MessageBox.Show("No se encontraron datos del calendario.");
                return;
            }

            idCalender = usuarioActivo.idCalender;
            SessionManager.setIdCalender(idCalender);

        }

        private void CargarDatosEvento()
        {
            string currentCalenderId = SessionManager.CurrentIdCalender;
            if (string.IsNullOrEmpty(currentCalenderId))
            {
                MessageBox.Show("No hay ID de calendario disponible para cargar eventos.");
                eventosDataGridView.DataSource = null;
                LimpiarDetalleEvento();
                return;
            }

            EventRepositorie repo = new EventRepositorie();
            List<EventModel> listaEventos = repo.GetEventsByCalenderId(currentCalenderId);

            if (listaEventos != null && listaEventos.Count > 0)
            {
                // Enlazar la lista al DataGridView
                eventosDataGridView.DataSource = null;
                eventosDataGridView.DataSource = listaEventos;

                // Configurar la visibilidad, encabezados y añadir los botones
                ConfigurarColumnasDataGridView();

                // Asegurar que haya una fila seleccionada (la primera)
                eventosDataGridView.ClearSelection();
                eventosDataGridView.Rows[0].Selected = true;

                CargarDetalleEventoSeleccionado(listaEventos[0]);
            }
            else
            {
                eventosDataGridView.DataSource = null;
                LimpiarDetalleEvento();
            }
        }

        // ... (código existente hasta ConfigurarColumnasDataGridView)

        private void ConfigurarColumnasDataGridView()
        {
            // --- Ocultar columnas internas ---
            if (eventosDataGridView.Columns.Contains("IdEvent")) eventosDataGridView.Columns["IdEvent"].Visible = false;
            if (eventosDataGridView.Columns.Contains("IdCalender")) eventosDataGridView.Columns["IdCalender"].Visible = false;
            if (eventosDataGridView.Columns.Contains("Description")) eventosDataGridView.Columns["Description"].Visible = false;
            if (eventosDataGridView.Columns.Contains("State")) eventosDataGridView.Columns["State"].Visible = false;
            if (eventosDataGridView.Columns.Contains("DisplaySummary")) eventosDataGridView.Columns["DisplaySummary"].Visible = false;

            // 🔑 Ocultar la columna IsPaid (que no usaremos ahora)
            if (eventosDataGridView.Columns.Contains("IsPaid"))
            {
                eventosDataGridView.Columns["IsPaid"].Visible = false;
            }

            // --- Configurar columnas de DATOS y establecer el ORDEN ---

            int displayIndex = 0;

            // Columna 1: Name
            if (eventosDataGridView.Columns.Contains("Name")) { eventosDataGridView.Columns["Name"].DisplayIndex = displayIndex++; eventosDataGridView.Columns["Name"].HeaderText = "Nombre"; }
            // Columna 2: Date
            if (eventosDataGridView.Columns.Contains("Date")) { eventosDataGridView.Columns["Date"].DisplayIndex = displayIndex++; eventosDataGridView.Columns["Date"].HeaderText = "Fecha"; }
            // Columna 3: Eventhour
            if (eventosDataGridView.Columns.Contains("Eventhour")) { eventosDataGridView.Columns["Eventhour"].DisplayIndex = displayIndex++; eventosDataGridView.Columns["Eventhour"].HeaderText = "Hora"; }
            // Columna 4: Ubication
            if (eventosDataGridView.Columns.Contains("Ubication")) { eventosDataGridView.Columns["Ubication"].DisplayIndex = displayIndex++; eventosDataGridView.Columns["Ubication"].HeaderText = "Ubicación"; }
            // Columna 5: NumberPhone
            if (eventosDataGridView.Columns.Contains("NumberPhone")) { eventosDataGridView.Columns["NumberPhone"].DisplayIndex = displayIndex++; eventosDataGridView.Columns["NumberPhone"].HeaderText = "Teléfono"; }
            // Columna 6: TypeEvent
            if (eventosDataGridView.Columns.Contains("TypeEvent")) { eventosDataGridView.Columns["TypeEvent"].DisplayIndex = displayIndex++; eventosDataGridView.Columns["TypeEvent"].HeaderText = "Tipo"; }
            // Columna 7: Monto
            if (eventosDataGridView.Columns.Contains("Monto")) { eventosDataGridView.Columns["Monto"].DisplayIndex = displayIndex++; eventosDataGridView.Columns["Monto"].HeaderText = "Monto"; }


            // 🔑 Columna 8: StatusDisplay (Con colores)
            if (!eventosDataGridView.Columns.Contains("StatusDisplay"))
            {
                // Creamos una columna de texto simple
                DataGridViewTextBoxColumn statusColumn = new DataGridViewTextBoxColumn
                {
                    Name = "StatusDisplay",
                    HeaderText = "Estatus de Pago",
                    ReadOnly = true,
                    DisplayIndex = displayIndex++
                };
                eventosDataGridView.Columns.Add(statusColumn);
            }
            else
            {
                eventosDataGridView.Columns["StatusDisplay"].DisplayIndex = displayIndex++;
            }

            // --- AÑADIR COLUMNAS DE BOTONES ---

            // Columna 9: BtnEditar
            if (!eventosDataGridView.Columns.Contains("BtnEditar"))
            {
                DataGridViewButtonColumn btnEditar = new DataGridViewButtonColumn();
                btnEditar.Name = "BtnEditar";
                btnEditar.HeaderText = "Editar";
                btnEditar.Text = "✏️ Editar";
                btnEditar.UseColumnTextForButtonValue = true;
                btnEditar.DisplayIndex = displayIndex++;
                eventosDataGridView.Columns.Add(btnEditar);
            }
            else
            {
                eventosDataGridView.Columns["BtnEditar"].DisplayIndex = displayIndex++;
            }

            // 🔑 Columna 10: BtnEliminar (Añadida la lógica de inserción)
            if (!eventosDataGridView.Columns.Contains("BtnEliminar"))
            {
                DataGridViewButtonColumn btnEliminar = new DataGridViewButtonColumn();
                btnEliminar.Name = "BtnEliminar";
                btnEliminar.HeaderText = "Eliminar";
                btnEliminar.Text = "🗑️ Eliminar";
                btnEliminar.UseColumnTextForButtonValue = true;
                btnEliminar.DisplayIndex = displayIndex++;
                eventosDataGridView.Columns.Add(btnEliminar);
            }
            else
            {
                eventosDataGridView.Columns["BtnEliminar"].DisplayIndex = displayIndex++;
            }


            // 🔑 Columna 11: BtnPagar (Añadida la lógica de inserción)
            if (!eventosDataGridView.Columns.Contains("BtnPagar"))
            {
                DataGridViewButtonColumn btnPagar = new DataGridViewButtonColumn();
                btnPagar.Name = "BtnPagar";
                btnPagar.HeaderText = "Pagar";
                btnPagar.Text = "Pagar";
                btnPagar.UseColumnTextForButtonValue = true;
                btnPagar.DisplayIndex = displayIndex++;
                eventosDataGridView.Columns.Add(btnPagar);
            }
            else
            {
                eventosDataGridView.Columns["BtnPagar"].DisplayIndex = displayIndex++;
            }


            eventosDataGridView.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            eventosDataGridView.ReadOnly = true;
        }

        // --- MÉTODO DE FORMATO DE CELDA Y BOTONES ---
        // Este método es el que ya tenías con la lógica de colores, pero lo incluí
        // completo para asegurarme de que esté en tu código.

        private void eventosDataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // Lógica para la columna "Date" (Mantenida)
            if (eventosDataGridView.Columns[e.ColumnIndex].Name == "Date")
            {
                if (e.Value != null && e.Value is string dateString)
                {
                    if (DateTime.TryParse(dateString, out DateTime dateValue))
                    {
                        e.Value = dateValue.ToShortDateString();
                        e.FormattingApplied = true;
                    }
                }
            }

            // 🔑 LÓGICA DE COLORES PARA EL ESTATUS DE PAGO
            if (eventosDataGridView.Columns[e.ColumnIndex].Name == "StatusDisplay")
            {
                EventModel evento = eventosDataGridView.Rows[e.RowIndex].DataBoundItem as EventModel;

                if (evento != null)
                {
                    if (evento.IsPaid)
                    {
                        // Estado Pagado (VERDE)
                        e.CellStyle.BackColor = Color.FromArgb(200, 255, 200); // Verde muy claro
                        e.CellStyle.ForeColor = Color.DarkGreen;
                        e.Value = "✅ Pagado";
                    }
                    else
                    {
                        // Estado Pendiente (ROJO)
                        e.CellStyle.BackColor = Color.FromArgb(255, 200, 200); // Rojo muy claro
                        e.CellStyle.ForeColor = Color.DarkRed;
                        e.Value = "❌ Pendiente";
                    }
                    e.FormattingApplied = true;
                }
            }


            // LÓGICA PARA DESHABILITAR LA APARIENCIA DEL BOTÓN "BtnPagar"
            if (eventosDataGridView.Columns[e.ColumnIndex].Name == "BtnPagar")
            {
                EventModel evento = eventosDataGridView.Rows[e.RowIndex].DataBoundItem as EventModel;

                if (evento != null && evento.IsPaid)
                {
                    // Si ya está pagado, cambia la apariencia para indicar que está "deshabilitado"
                    e.CellStyle.ForeColor = Color.DarkGray;
                    e.CellStyle.SelectionForeColor = Color.DarkGray;
                    e.CellStyle.BackColor = Color.Gainsboro;
                    e.CellStyle.SelectionBackColor = Color.Gainsboro;
                    e.Value = "Pagado";
                    e.FormattingApplied = true;
                }
                else
                {
                    // Restaurar colores por defecto (botón activo)
                    e.CellStyle.ForeColor = Color.White;
                    e.CellStyle.BackColor = Color.DodgerBlue;
                    e.CellStyle.SelectionBackColor = Color.RoyalBlue;
                    e.Value = "Pagar";
                }
            }
        }


        // Dentro de calendario.cs

        private void eventosDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            string columnName = eventosDataGridView.Columns[e.ColumnIndex].Name;

            // Llamar a CellClick solo si es una de las columnas de botones
            if (columnName == "BtnEditar" || columnName == "BtnEliminar" || columnName == "BtnPagar")
            {
                eventosDataGridView_CellClick(sender, e);
            }

        }
        // Dentro de calendario.cs

        private void eventosDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            string columnName = eventosDataGridView.Columns[e.ColumnIndex].Name;

            EventModel eventoSeleccionado = eventosDataGridView.Rows[e.RowIndex].DataBoundItem as EventModel;

            if (eventoSeleccionado == null) return;

            idEvent = eventoSeleccionado.IdEvent;
            eventName = eventoSeleccionado.Name;

            // ... (otras asignaciones de variables de clase si son necesarias)

            if (columnName == "BtnEditar")
            {
                if (eventoSeleccionado.IsPaid)
                {
                    return; 
                }

                EditarEventoSeleccionado();
            }
            else if (columnName == "BtnEliminar")
            {
                EliminarEventoSeleccionado();
            }
            else if (columnName == "BtnPagar")
            {
                if (eventoSeleccionado.IsPaid)
                {
                    return; 
                }

                PagarEvento(eventoSeleccionado);
            }
        }
        private void EditarEventoSeleccionado()
        {
            if (string.IsNullOrEmpty(idEvent))
            {
                MessageBox.Show("Error al obtener ID de evento para edición.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show($"Abriendo formulario de edición para el Evento ID: {idEvent} ({eventName})", "Editar Evento");
        }

        private void EliminarEventoSeleccionado()
        {
            if (string.IsNullOrEmpty(idEvent))
            {
                MessageBox.Show("Error al obtener ID de evento para eliminación.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show(
              $"¿Estás seguro de que quieres eliminar el evento '{eventName}')?",
              "Confirmar Eliminación",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                EventRepositorie repo = new EventRepositorie();

                if (repo.EliminarEvento(idEvent))
                {
                    MessageBox.Show("Evento eliminado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Recargar la lista después de eliminar
                    RefrescarDatos();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el evento. Verifica la conexión a la DB.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // calendario.cs - Método PagarEvento (Mantenido y APROBADO)
        private void PagarEvento(EventModel evento)
        {
            using (var formPagar = new PagarEvento(evento.Monto))
            {
                DialogResult result = formPagar.ShowDialog();

                if (result == DialogResult.OK)
                {
                    try
                    {
                        EventRepositorie repo = new EventRepositorie();

                        // 🔑 1. Marcar el evento como pagado 
                        if (repo.MarcarComoPagado(evento.IdEvent))
                        {
                            MessageBox.Show("Venta registrada y estado de evento actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Venta registrada, pero falló la actualización del estado del evento.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }

                        // 2. Recargar el DataGridView para actualizar el estado visual
                        RefrescarDatos();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ocurrió un error al intentar actualizar el estado del evento: " + ex.Message, "Error de Actualización", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // --- MÉTODOS DE VISUALIZACIÓN DE DETALLES ---

        private void eventosDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (eventosDataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow filaSeleccionada = eventosDataGridView.SelectedRows[0];
                EventModel eventoSeleccionado = filaSeleccionada.DataBoundItem as EventModel;

                if (eventoSeleccionado != null)
                {
                    CargarDetalleEventoSeleccionado(eventoSeleccionado);
                }
            }
            else
            {
                LimpiarDetalleEvento();
            }
        }

        private void CargarDetalleEventoSeleccionado(EventModel evento)
        {
            // Asignar todas las variables de clase
            idEvent = evento.IdEvent;
            eventName = evento.Name;
            eventHour = evento.Eventhour;
            dateEvent = evento.Date;
            eventDescription = evento.Description;
            eventUbication = evento.Ubication;
            eventNumberPhone = evento.NumberPhone;
            eventType = evento.TypeEvent;
            eventMonto = evento.Monto;

            // **Aquí deberías añadir la lógica para actualizar tus Labels y el monthCalendar1**
        }

        private void LimpiarDetalleEvento()
        {
            idEvent = string.Empty;
            eventName = string.Empty;
            eventDescription = string.Empty;
            // **Aquí deberías añadir la lógica para limpiar tus Labels**
        }


        // --- MÉTODOS DE RECARGA Y NAVEGACIÓN ---

        public void RefrescarDatos()
        {
            CargarDatosCalender();
            CargarDatosEvento();
        }

        // ... Métodos de navegación ...
        private void inventary_Click(object sender, EventArgs e)
        {
            IrACatalog?.Invoke(this, EventArgs.Empty);
        }

        private void homePage_Click(object sender, EventArgs e)
        {
            IrAInicio?.Invoke(this, EventArgs.Empty);
        }

        private void agendar_Click(object sender, EventArgs e)
        {
            IrAAgendarEvento?.Invoke(this, EventArgs.Empty);
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void Profile_Click(object sender, EventArgs e)
        {
            IrAProfile?.Invoke(this, EventArgs.Empty);

        }

        private void CatalogButton_Click(object sender, EventArgs e)
        {
            IrAInventario?.Invoke(this, EventArgs.Empty);
        }
    }
}