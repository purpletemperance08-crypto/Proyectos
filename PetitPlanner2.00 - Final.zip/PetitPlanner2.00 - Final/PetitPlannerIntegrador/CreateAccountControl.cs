﻿using MySqlConnector;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Data;

namespace PetitPlannerIntegrador
{
    // *** LA CLASE NewUserData HA SIDO ELIMINADA DE AQUÍ ***

    public partial class CreateAccountControl : UserControl
    {
        // Eventos que disparan la navegación
        public event EventHandler CuentaCreadaExitosa;
        public event EventHandler<string> CuentaFallida;
        public event EventHandler VolverAtras;
        public event EventHandler LoginExitoso;


        public CreateAccountControl()
        {
            // Esta línea es esencial y debe estar aquí.
            InitializeComponent();
        }

        // --- LÓGICA DE VERIFICACIÓN DE EMAIL ---
        private bool EsEmailValido(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;
            string patron = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, patron, RegexOptions.IgnoreCase);
        }


        // 🚀 MÉTODO MODIFICADO: Devuelve solo el UserId y asume 'nombreNegocio'
        private string CrearUsuarioYRecursos(string usuario, string password, string gmail, string nombreNegocio, string connectionString)
        {
            string userId = null;
            string bussinesId = null;
            string inventoryId = null;
            string calendarId = null;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // PASO 1: Insertar Usuario y obtener ID
                    string userQuery = @"
                        INSERT INTO usuarios (user, password, email) VALUES (@usuario, @password, @gmail);
                        SELECT LAST_INSERT_ID();";

                    using (MySqlCommand command = new MySqlCommand(userQuery, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@usuario", usuario);
                        command.Parameters.AddWithValue("@password", password);
                        command.Parameters.AddWithValue("@gmail", gmail);
                        object idResult = command.ExecuteScalar();
                        if (idResult == null || idResult == DBNull.Value || Convert.ToInt32(idResult) == 0)
                            throw new Exception("Error al obtener el ID del usuario.");
                        userId = idResult.ToString();
                    }

                    // PASO 2: Crear Bussines
                    string bussinesQuery = @"
                        INSERT INTO bussines (id_user, name) VALUES (@userId, @nombreNegocio);
                        SELECT LAST_INSERT_ID();";

                    using (MySqlCommand command = new MySqlCommand(bussinesQuery, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        command.Parameters.AddWithValue("@nombreNegocio", nombreNegocio); // Usamos el nuevo campo
                        object bussinesIdResult = command.ExecuteScalar();
                        if (bussinesIdResult == null || bussinesIdResult == DBNull.Value)
                            throw new Exception("Error al obtener el ID de Bussines.");
                        bussinesId = bussinesIdResult.ToString();
                    }

                    // PASO 3: Crear Inventory 
                    string inventoryQuery = @"
                        INSERT INTO inventory (id_bussines) VALUES (@bussinesId);
                        SELECT LAST_INSERT_ID();";
                    using (MySqlCommand command = new MySqlCommand(inventoryQuery, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@bussinesId", bussinesId);
                        object inventoryIdResult = command.ExecuteScalar();
                        if (inventoryIdResult == null || inventoryIdResult == DBNull.Value)
                            throw new Exception("Error al obtener el ID de Inventory.");
                        inventoryId = inventoryIdResult.ToString();
                    }

                    // PASO 4: Crear Calendar
                    string calendarQuery = @"
                        INSERT INTO calender (id_bussines) VALUES (@bussinesId);
                        SELECT LAST_INSERT_ID();";
                    using (MySqlCommand command = new MySqlCommand(calendarQuery, connection, transaction))
                    {
                        command.Parameters.AddWithValue("@bussinesId", bussinesId);
                        object calendarIdResult = command.ExecuteScalar();
                        if (calendarIdResult == null || calendarIdResult == DBNull.Value)
                            throw new Exception("Error al obtener el ID de Calendar.");
                        calendarId = calendarIdResult.ToString();
                    }

                    transaction.Commit();

                    // 🔑 Guardamos todos los IDs en SessionManager aquí mismo
                    SessionManager.setIdBussines(bussinesId);
                    SessionManager.setIdInventory(inventoryId);
                    SessionManager.setIdCalender(calendarId);

                    // Devolvemos solo el ID del usuario
                    return userId;
                }
                catch (MySqlException)
                {
                    transaction.Rollback();
                    throw;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw new Exception($"Falló la creación de recursos: {ex.Message}");
                }
            }
        }


        private void create_Click(object sender, EventArgs e)
        {
            string usuario = textBoxUsuario.Text;
            string password = textBoxPassword.Text;
            string passwordConfirm = textBoxPasswordConfirm.Text;
            string gmail = textBoxGmail.Text;

            // 🚨 Debes asegurarte que tienes un control llamado textBoxNombreNegocio
            string nombreNegocio = textBoxNombreNegocio.Text;

            string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;Allow User Variables=true;";

            // 1. Validaciones (Se incluye el campo del negocio)
            if (string.IsNullOrEmpty(usuario) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(gmail) || string.IsNullOrEmpty(nombreNegocio))
            {
                MessageBox.Show("Por favor, complete todos los campos, incluido el nombre del negocio.");
                return;
            }
            // ... (otras validaciones) ...
            if (password != passwordConfirm)
            {
                MessageBox.Show("❌ Las contraseñas no son iguales");
                textBoxPassword.Focus();
                return;
            }

            try
            {
                string userId = CrearUsuarioYRecursos(usuario, password, gmail, nombreNegocio, connectionString);

                if (userId != null)
                {

                    SessionManager.StartSession(userId);


                    LoginExitoso?.Invoke(this, EventArgs.Empty);
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                {
                    MessageBox.Show("❌ El usuario o email ya existe");
                }
                else
                {
                    MessageBox.Show($"❌ Error de base de datos: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error fatal durante la creación de recursos: {ex.Message}");
            }
        }

        private void volver_Click(object sender, EventArgs e)
        {
            VolverAtras?.Invoke(this, EventArgs.Empty);
        }

        // Métodos de UI que deben estar vacíos
        private void CreateAccountControl_Load(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void textBoxPasswordConfirm_TextChanged(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void pictureBox3_Click(object sender, EventArgs e) { }
        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e) { }
    }
}