﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    // MainForm.cs
    public partial class MainForm : Form
    {
        private Panel panelContenedor;
        private agendarEvento _agendarEventoInstance = null;

        private realizarCotizacion _cotizacionFormInstance = null;

        public MainForm()
        {
            InitializeComponent();
            
            ConfigurarInterfaz();
            MostrarInicio();
        }

        private void ConfigurarInterfaz()
        {
            this.Text = "Petit Planner";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            panelContenedor = new Panel();
            panelContenedor.Dock = DockStyle.Fill;
            this.Controls.Add(panelContenedor);
        }

        private void MostrarInicio()
        {
            var loginControl = new LoginControl();
            loginControl.Dock = DockStyle.Fill;
            loginControl.LoginExitoso += (s, e) => MostrarHomePage();

            loginControl.LoginFallido += (s, mensaje) =>
            {
                Console.WriteLine($"Login fallido: {mensaje}");
            };
            loginControl.IrACreateAccount += (s, e) => MostrarCrearCuenta();


            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(loginControl);
        }

        private void MostrarCrearCuenta()
        {
            var CreateAccountControl = new CreateAccountControl();
            CreateAccountControl.Dock = DockStyle.Fill;
            CreateAccountControl.CuentaCreadaExitosa += (s, e) => MostrarHomePage();
            CreateAccountControl.CuentaFallida += (s, mensaje) =>
            {
                // Opcional: manejar errores específicos
                Console.WriteLine($"Login fallido: {mensaje}");
            };
            CreateAccountControl.VolverAtras += (s, e) => MostrarInicio();
            CreateAccountControl.LoginExitoso += (s, e) => MostrarHomePage();


            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(CreateAccountControl);
        }

        

        private void MostrarInventario()
        {
            var inventoryControl = new inventory();
            inventoryControl.Dock = DockStyle.Fill;

            inventoryControl.IrAInicio += (s, e) => MostrarHomePage();
            inventoryControl.IrACalendario += (s, e) => MostrarCalendario();
            inventoryControl.IrAAgendarEvento += (s, e) => MostrarAgendarEvento();
            inventoryControl.IrAAgregarArticulo += (s, e) => MostrarAgregarArticulo();
            inventoryControl.IrAProfile += (s, e) => MostrarPerfil();
            inventoryControl.IrACatalogo += (s, e) => MostrarCatalogo();

            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(inventoryControl);
            inventoryControl.RefrescarDatos();
        }

        private void MostrarCatalogo()
        {
            var catalogControl = new catalog();
            catalogControl.Dock = DockStyle.Fill;

            // 1. Eventos ya existentes
            catalogControl.IrAHomePage += (s, e) => MostrarHomePage();
            catalogControl.IrAAñadirCatalog += (s, e) => MostrarAñadirCatalog();

            // 2. Eventos de la barra lateral añadidos
            catalogControl.IrAInventoryPage += (s, e) => MostrarInventario();
            catalogControl.IrACalendarPage += (s, e) => MostrarCalendario();
            catalogControl.IrAAgendarPage += (s, e) => MostrarAgendarEvento();
            catalogControl.IrAProfilePage += (s, e) => MostrarPerfil();
            catalogControl.IrAInventory += (s, e) => MostrarInventario();

            // Mostrar el control
            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(catalogControl);
        }

        private void MostrarAñadirCatalog()
        {
            var añadirCatalogControl = new añadirCatalog();
            añadirCatalogControl.Dock = DockStyle.Fill;
            añadirCatalogControl.VolverAtras += (s, e) => MostrarCatalogo();
            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(añadirCatalogControl);
        }

        private void MostrarCalendario()
        {
            var calendarioControl = new calendario();
            calendarioControl.Dock = DockStyle.Fill;
            calendarioControl.IrAInventario += (s, e) => MostrarInventario();
            calendarioControl.IrAInicio += (s, e) => MostrarHomePage();
            calendarioControl.IrAAgendarEvento += (s, e) => MostrarAgendarEvento();
            calendarioControl.IrAProfile += (s, e) => MostrarPerfil();
            calendarioControl.IrACatalog += (s, e) => MostrarCatalogo();

            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(calendarioControl);
            calendarioControl.RefrescarDatos(); 
        }

        private void MostrarAgregarArticulo()
        {
            var agregarArticuloControl = new añadirArticulo();
            agregarArticuloControl.Dock = DockStyle.Fill;
            agregarArticuloControl.ArticuloAgregado += (s, e) =>
            {
                MessageBox.Show("Artículo agregado correctamente");
                MostrarInventario();
            };

            agregarArticuloControl.Cancelar += (s, e) => MostrarInventario();
            agregarArticuloControl.VolverAtras += (s, e) => MostrarInventario();


            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(agregarArticuloControl);
        }

        private void MostrarHomePage()
        {
            var homePageControl = new homePageControl();
            homePageControl.Dock = DockStyle.Fill;
            homePageControl.IrAInventario += (s, e) => MostrarInventario();
            homePageControl.IrAProfile += (s, e) => MostrarCalendario();
            homePageControl.IrAAgendarEvento += (s, e) => MostrarAgendarEvento();
            homePageControl.IrAPerfil += (s, e) => MostrarPerfil();
            homePageControl.cerrarSesion += (s, e) => MostrarInicio();
            homePageControl.IrACatalog += (s, e) => MostrarCatalogo();
            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(homePageControl);
        }

        private void MostrarAgendarEvento()
        {
            if (_agendarEventoInstance == null)
            {
                _agendarEventoInstance = new agendarEvento();
                _agendarEventoInstance.Dock = DockStyle.Fill;

                
                _agendarEventoInstance.IrACalendario += (s, e) => MostrarCalendario();
                _agendarEventoInstance.IrAInicio += (s, e) => MostrarHomePage();
                _agendarEventoInstance.IrAProfile += (s, e) => MostrarPerfil();
                _agendarEventoInstance.IrARealizarCotizacion += (s, e) => MostrarRealizarCotizacion();
                _agendarEventoInstance.IrACatalog += (s, e) => MostrarCatalogo();

                _agendarEventoInstance.EventoAgregado += (s, e) =>
                {
                    MessageBox.Show("Evento agregado correctamente.");
                   
                };

                panelContenedor.Controls.Add(_agendarEventoInstance);
            }
            _agendarEventoInstance.CargarMontoCotizado();

            panelContenedor.Controls.Clear();

            panelContenedor.Controls.Add(_agendarEventoInstance);
            _agendarEventoInstance.Show();
            _agendarEventoInstance.BringToFront();
        }
        private void MostrarRealizarCotizacion()
        {
            // 1. Instanciar el Form de Cotización
            var cotizacionForm = new realizarCotizacion();

            // 2. Aplicar las configuraciones necesarias para INCUSTAR un Form (ventana)
            //    Esto resuelve el error "Top-level control cannot be added to a control".
            cotizacionForm.TopLevel = false;
            cotizacionForm.FormBorderStyle = FormBorderStyle.None;
            cotizacionForm.Dock = DockStyle.Fill; // Usar Dock.Fill aquí es mejor que en la línea 3

            // 3. Conectar eventos
            // El evento FinalizarCotizacion debe llevar al usuario de vuelta a la agenda
            cotizacionForm.FinalizarCotizacion += (s, e) => MostrarAgendarEvento();

            // 4. Limpiar el contenedor anterior y añadir el nuevo Form/Control
            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(cotizacionForm);

            // 5. Mostrar el Form incrustado (necesario ya que es un Form)
            cotizacionForm.Show();
        }

        private void MostrarPerfil()
        {
            var profile = new profile();
            profile.Dock = DockStyle.Fill;

            profile.IrAInventario += (s, e) => MostrarInventario();
            profile.IrAInicio += (s, e) => MostrarHomePage();
            profile.IrACalendario += (s, e) => MostrarCalendario();
            profile.IrAAgendarEvento += (s, e) => MostrarAgendarEvento();
            profile.cerrarSesion += (s, e) => MostrarInicio();
            profile.IrACatalog += (s, e) => MostrarCatalogo();

            panelContenedor.Controls.Clear();
            panelContenedor.Controls.Add(profile);
        }


    }
}
