﻿namespace PetitPlannerIntegrador
{
    partial class añadirArticulo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            backInventory = new Button();
            dataGridView1 = new DataGridView();
            Eliminar = new Button();
            Editar = new Button();
            button3 = new Button();
            labelTitle = new Label();
            panelActions = new Panel();
            panelHeader = new Panel();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panelActions.SuspendLayout();
            panelHeader.SuspendLayout();
            SuspendLayout();
            // 
            // backInventory
            // 
            backInventory.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            backInventory.BackColor = Color.FromArgb(48, 63, 159);
            backInventory.FlatAppearance.BorderSize = 0;
            backInventory.FlatStyle = FlatStyle.Flat;
            backInventory.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            backInventory.ForeColor = Color.White;
            backInventory.Location = new Point(650, 22);
            backInventory.Name = "backInventory";
            backInventory.Size = new Size(250, 50);
            backInventory.TabIndex = 0;
            backInventory.Text = "← BACK";
            backInventory.UseVisualStyleBackColor = false;
            backInventory.Click += backInventory_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.BackgroundColor = Color.FromArgb(232, 239, 253);
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.White;
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 9F);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.Location = new Point(3, 97);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 30;
            dataGridView1.Size = new Size(984, 400);
            dataGridView1.TabIndex = 8;
            // 
            // Eliminar
            // 
            Eliminar.BackColor = Color.FromArgb(220, 53, 69);
            Eliminar.FlatAppearance.BorderSize = 0;
            Eliminar.FlatStyle = FlatStyle.Flat;
            Eliminar.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            Eliminar.ForeColor = Color.White;
            Eliminar.Location = new Point(20, 180);
            Eliminar.Name = "Eliminar";
            Eliminar.Size = new Size(250, 60);
            Eliminar.TabIndex = 10;
            Eliminar.Text = "Delete Article";
            Eliminar.UseVisualStyleBackColor = false;
            Eliminar.Click += Eliminar_Click_1;
            // 
            // Editar
            // 
            Editar.BackColor = Color.FromArgb(255, 193, 7);
            Editar.FlatAppearance.BorderSize = 0;
            Editar.FlatStyle = FlatStyle.Flat;
            Editar.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            Editar.ForeColor = Color.Black;
            Editar.Location = new Point(20, 100);
            Editar.Name = "Editar";
            Editar.Size = new Size(250, 60);
            Editar.TabIndex = 11;
            Editar.Text = "Edit Article";
            Editar.UseVisualStyleBackColor = false;
            Editar.Click += Editar_Click_1;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(12, 67, 122);
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(20, 20);
            button3.Name = "button3";
            button3.Size = new Size(250, 60);
            button3.TabIndex = 12;
            button3.Text = "Add Article";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.BackColor = Color.White;
            labelTitle.Font = new Font("Century Gothic", 18F, FontStyle.Bold);
            labelTitle.ForeColor = Color.FromArgb(12, 67, 122);
            labelTitle.Location = new Point(30, 20);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(321, 43);
            labelTitle.TabIndex = 13;
            labelTitle.Text = "Manage Catalog";
            // 
            // panelActions
            // 
            panelActions.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panelActions.BackColor = Color.White;
            panelActions.Controls.Add(button3);
            panelActions.Controls.Add(Eliminar);
            panelActions.Controls.Add(Editar);
            panelActions.Location = new Point(630, 175);
            panelActions.Name = "panelActions";
            panelActions.Size = new Size(290, 262);
            panelActions.TabIndex = 14;
            // 
            // panelHeader
            // 
            panelHeader.BackColor = Color.White;
            panelHeader.Controls.Add(labelTitle);
            panelHeader.Controls.Add(backInventory);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Location = new Point(0, 0);
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(990, 91);
            panelHeader.TabIndex = 15;
            // 
            // añadirArticulo
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(232, 239, 253);
            Controls.Add(panelActions);
            Controls.Add(dataGridView1);
            Controls.Add(panelHeader);
            MinimumSize = new Size(800, 400);
            Name = "añadirArticulo";
            Size = new Size(990, 550);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panelActions.ResumeLayout(false);
            panelHeader.ResumeLayout(false);
            panelHeader.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button backInventory;
        private DataGridView dataGridView1;
        private Button Eliminar;
        private Button Editar;
        private Button button3;
        private Label labelTitle;
        private Panel panelActions;
        private Panel panelHeader;
    }
}