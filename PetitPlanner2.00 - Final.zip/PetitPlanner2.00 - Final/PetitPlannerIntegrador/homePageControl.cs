﻿using MySqlConnector;
using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace PetitPlannerIntegrador
{
    public partial class homePageControl : UserControl
    {
        public event EventHandler IrAInventario;
        public event EventHandler IrAProfile;
        public event EventHandler IrAAgendarEvento;
        public event EventHandler IrAPerfil;
        public event EventHandler cerrarSesion;
        public event EventHandler IrACatalog;

        private string IdInventorio;

        public homePageControl()
        {
            InitializeComponent();

            // 🔥 FIX: Asegurar que el Load event sí se ejecute
            this.Load += homePageControl_Load;

            CargarBusinessId();
            DatosDelInventario();
            CargarTotalesYGrafica();
        }

        // ===============================================
        // MODEL FOR SELL TABLE
        // ===============================================
        public class VentaModel
        {
            public int IdSell { get; set; }
            public int IdBusiness { get; set; }
            public decimal Cost { get; set; }
            public decimal Investment { get; set; }
            public decimal Earnings { get; set; }
        }

        // ===============================================
        // LOAD HOMEPAGE
        // ===============================================
        private void homePageControl_Load(object sender, EventArgs e)
        {
            CargarGraficaVentas();
        }

        // ===============================================
        // LOAD REAL GRAPH FROM DATABASE
        // ===============================================


        private void CargarGraficaVentas()
        {
            if (string.IsNullOrEmpty(SessionManager.CurrentIdBusiness))
            {
                MessageBox.Show("❌ No hay Business ID en sesión");
                return;
            }

            string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";
            string query = "SELECT investment, earnings FROM sell WHERE id_bussines = @idBusiness";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@idBusiness", SessionManager.CurrentIdBusiness);

                    conn.Open();
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        // 🔥 FIX: limpiar todo antes de dibujar la gráfica
                        chart1.Series.Clear();
                        chart1.Titles.Clear();

                        Series serie = new Series("Earnings");
                        serie.ChartType = SeriesChartType.Column;
                        serie.XValueType = ChartValueType.Double;

                        bool hayDatos = false;

                        while (reader.Read())
                        {
                            hayDatos = true;
                            decimal investment = reader.GetDecimal("investment");
                            decimal earnings = reader.GetDecimal("earnings");

                            serie.Points.AddXY(investment, earnings);
                        }

                        if (!hayDatos)
                        {
                            MessageBox.Show("No hay datos de ventas para graficar.");
                            return;
                        }

                        chart1.Series.Add(serie);

                        // Estilo ejes
                        chart1.ChartAreas[0].AxisX.Title = "Investment";
                        chart1.ChartAreas[0].AxisY.Title = "Earnings";

                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error cargando gráfica: " + ex.Message);
            }
        }





        // ===========================================
        // MÉTODO DE ENTRADA CENTRAL (LIMPIO)
        // ===========================================
        /// <summary>
        /// Centraliza la carga de datos de la Home Page, enfocándose solo en los totales.
        /// Se llama desde el constructor y el evento Load.
        /// </summary>
        private void CargarTotalesYGrafica()
        {
            string businessId = SessionManager.CurrentIdBusiness;

            if (string.IsNullOrEmpty(businessId))
            {
                // En un entorno de producción, esto debería registrarse o mostrarse de forma elegante.
                return;
            }

            // Llama al método de Display para cargar Costo, Inversión y Ganancias.
            CargarTotalesEnLabels(businessId);
        }

        // ===========================================
        // MÉTODOS DE SUMA (Lógica de acceso a datos)
        // ===========================================

        /// <summary>
        /// Obtiene la suma total de una columna específica ('cost', 'investment', o 'earnings') 
        /// para el negocio actual usando SUM() en SQL.
        /// </summary>
        private decimal ObtenerSumaTotal(string columnName, string idBusiness)
        {
            decimal total = 0;
            string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";

            // Usamos SUM() directamente en SQL para mayor eficiencia
            string query = $"SELECT SUM({columnName}) FROM sell WHERE id_bussines = @idBusiness";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@idBusiness", idBusiness);

                    conn.Open();

                    // ExecuteScalar devuelve el primer valor de la primera fila (la suma)
                    object result = cmd.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        total = Convert.ToDecimal(result);
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores silencioso en la versión final
                // Console.WriteLine($"Error al obtener el total de {columnName}: {ex.Message}");
            }

            return total;
        }

        // ===========================================
        // MÉTODO DE DISPLAY (Asignación a etiquetas)
        // ===========================================

        /// <summary>
        /// Muestra los totales en las etiquetas label4 (Costo), label5 (Inversión) y label6 (Ganancias).
        /// </summary>
        private void CargarTotalesEnLabels(string businessId)
        {
            // Costo Total (label4)
            decimal totalCost = ObtenerSumaTotal("cost", businessId);
            label4.Text = totalCost.ToString("C2"); // Formato de moneda

            // Inversión Total (label5)
            decimal totalInvestment = ObtenerSumaTotal("investment", businessId);
            label5.Text = totalInvestment.ToString("C2"); // Formato de moneda

            // Ganancias Totales (label6)
            decimal totalEarnings = ObtenerSumaTotal("earnings", businessId);
            label6.Text = totalEarnings.ToString("C2"); // Formato de moneda
        }



        // ===============================================
        // LOAD INVENTORY
        // ===============================================
        private void DatosDelInventario()
        {
            InventoryRepositorie repo = new InventoryRepositorie();
            inventoryModel? usuarioActivo = repo.UserInformation();

            if (usuarioActivo != null)
            {
                IdInventorio = usuarioActivo.idInventory;
                SessionManager.setIdInventory(IdInventorio);
            }
            else
            {
                MessageBox.Show("Error al cargar la información de usuario o sesión expirada.");
            }
        }

        // ===============================================
        // LOAD BUSINESS ID
        // ===============================================
        private void CargarBusinessId()
        {
            string userId = SessionManager.CurrentUserId;

            if (string.IsNullOrEmpty(userId))
            {
                MessageBox.Show("❌ No hay usuario logueado");
                return;
            }

            string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";
            string query = "SELECT id_bussines FROM bussines WHERE id_user = @userId";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userId", userId);

                    connection.Open();
                    object result = command.ExecuteScalar();
                    string businessId = result?.ToString();

                    if (!string.IsNullOrEmpty(businessId))
                    {
                        SessionManager.setIdBussines(businessId);
                    }
                    else
                    {
                        MessageBox.Show("❌ No se encontró business para este usuario");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error al cargar business ID: {ex.Message}");
            }
        }

        // ===============================================
        // BUTTONS
        // ===============================================
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(SessionManager.CurrentIdBusiness))
            {
                MessageBox.Show("❌ Business ID no disponible");
                return;
            }

            IrACatalog?.Invoke(this, EventArgs.Empty);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IrAProfile?.Invoke(this, EventArgs.Empty);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IrAAgendarEvento?.Invoke(this, EventArgs.Empty);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            IrAProfile?.Invoke(this, EventArgs.Empty);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SessionManager.EndSession();
            cerrarSesion?.Invoke(this, EventArgs.Empty);
        }

        private void catalogo_Click(object sender, EventArgs e)
        {
            IrAInventario?.Invoke(this, EventArgs.Empty);
        }

        private void panel4_Paint(object sender, PaintEventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
    }
}
