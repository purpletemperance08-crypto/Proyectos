﻿using MySqlConnector;
using System;
using System.Windows.Forms;
// Asume que SessionManager está en el namespace PetitPlannerIntegrador o tiene la referencia necesaria
// using PetitPlannerIntegrador.Repositories; 

namespace PetitPlannerIntegrador
{
    public partial class PagarEvento : Form
    {
        // Atributos de clase
        private readonly string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";
        private decimal _montoTotal;
        private int _idBusiness;

        // Constructor sin argumentos
        public PagarEvento()
        {
            InitializeComponent();
        }

        // 🔑 Constructor para recibir Monto (el ID se jala del SessionManager)
        public PagarEvento(decimal montoDelEvento)
        {
            InitializeComponent();

            _montoTotal = montoDelEvento;

            // 🔑 JALAR id_bussines del SessionManager
            string idBusinessString = SessionManager.CurrentIdBusiness;

            if (string.IsNullOrEmpty(idBusinessString) || !int.TryParse(idBusinessString, out int idBus))
            {
                _idBusiness = 0;
                MessageBox.Show("Error al obtener el ID de negocio desde la sesión. La venta no se asociará correctamente.", "Error de Sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                _idBusiness = idBus;
            }

            this.textTotal.Text = _montoTotal.ToString("C2");
            this.textTotal.ReadOnly = true;
        }

        // Manejador del Botón de Confirmar Pago (button1_Click)
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textInvestment.Text))
            {
                MessageBox.Show("Por favor, ingrese el monto de inversión.", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textInvestment.Focus();
                return;
            }

            string investmentText = textInvestment.Text.Replace("$", "").Replace(",", "").Trim();

            if (!decimal.TryParse(investmentText, out decimal investment))
            {
                MessageBox.Show("El valor de inversión no es un número válido.", "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (_idBusiness == 0)
            {
                MessageBox.Show("No se puede completar el pago: ID de negocio inválido.", "Error de Base de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            decimal cost = _montoTotal;
            decimal earnings = cost - investment;

            // Inserción en la tabla 'sell'
            if (InsertarVentaConGanancia(cost, investment, earnings, _idBusiness))
            {
                MessageBox.Show("Venta registrada y ganancia calculada con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        // Método para insertar datos en la tabla 'sell'
        private bool InsertarVentaConGanancia(decimal cost, decimal investment, decimal earnings, int idBusiness)
        {
            string query = "INSERT INTO sell (id_bussines, cost, investment, earnings) VALUES (@idBussines, @cost, @investment, @earnings)";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idBussines", idBusiness);
                    command.Parameters.AddWithValue("@cost", cost);
                    command.Parameters.AddWithValue("@investment", investment);
                    command.Parameters.AddWithValue("@earnings", earnings);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la venta en la base de datos: " + ex.Message, "Error de DB", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}