﻿using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    public partial class inventory : UserControl
    {
        private string IdInventorio;

        public event EventHandler IrAInicio;
        public event EventHandler IrACalendario;
        public event EventHandler IrAAgregarArticulo;
        public event EventHandler IrAAgendarEvento;
        public event EventHandler IrAProfile;
        public event EventHandler IrACatalogo;

        public inventory()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // 🛑 MODIFICACIÓN CLAVE: Bloquear la edición de la tabla
            dataGridView1.ReadOnly = true;

            DatosDelNegocio();
            cargarDatosProductos();
        }


        private void DatosDelNegocio()
        {
            InventoryRepositorie repo = new InventoryRepositorie();
            inventoryModel? usuarioActivo = repo.UserInformation();

            if (usuarioActivo != null)
            {
                IdInventorio = usuarioActivo.idInventory;
                inventoryId.Text = IdInventorio;
                SessionManager.setIdInventory(IdInventorio);
            }
            else
            {
                MessageBox.Show("Error al cargar la información de usuario o sesión expirada.");
            }
        }

        private void cargarDatosProductos()
        {
            ProductRepositorie repo = new ProductRepositorie();
            var productos = repo.GetProductsByInventoryId(SessionManager.CurrentIdInventory);

            if (string.IsNullOrEmpty(SessionManager.CurrentIdInventory))
            {
                dataGridView1.DataSource = null;
                MessageBox.Show("Error: ID de Inventario no cargado.", "Error de Sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            dataGridView1.DataSource = productos;


            if (dataGridView1.Columns.Contains("IdInventario"))
            {
                dataGridView1.Columns["IdInventario"].Visible = false;
            }

            if (dataGridView1.Columns.Contains("IdProducto"))
            {
                dataGridView1.Columns["IdProducto"].Visible = false;
            }
        }



        private void botonAtras_Click(object sender, EventArgs e) => IrAInicio?.Invoke(this, EventArgs.Empty);
        private void homePage_Click(object sender, EventArgs e) => IrAInicio?.Invoke(this, EventArgs.Empty);
        private void calendario_Click(object sender, EventArgs e) => IrACalendario?.Invoke(this, EventArgs.Empty);
        public void RefrescarDatos() => cargarDatosProductos();
        private void añadirArticulo_Click_1(object sender, EventArgs e) => IrAAgregarArticulo?.Invoke(this, EventArgs.Empty);

        private void agendar_Click(object sender, EventArgs e)
        {
            IrAAgendarEvento?.Invoke(this, EventArgs.Empty);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IrAProfile?.Invoke(this, EventArgs.Empty);

        }

        private void catalogo_Click(object sender, EventArgs e)
        {
            IrACatalogo?.Invoke(this, EventArgs.Empty);
        }
    }
}