﻿namespace PetitPlannerIntegrador
{
    partial class profile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button5 = new Button();
            Catalogo = new Button();
            button1 = new Button();
            panel2 = new Panel();
            label10 = new Label();
            label11 = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            panelContenido = new Panel();
            panelPassword = new Panel();
            passwordUser = new RichTextBox();
            panelBusiness = new Panel();
            userBussinesName = new RichTextBox();
            panelUser = new Panel();
            userName = new RichTextBox();
            panelEmail = new Panel();
            emailUser = new RichTextBox();
            button6 = new Button();
            panel5 = new Panel();
            labelTitle = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panelContenido.SuspendLayout();
            panelPassword.SuspendLayout();
            panelBusiness.SuspendLayout();
            panelUser.SuspendLayout();
            panelEmail.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.FromArgb(12, 67, 122);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(Catalogo);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 800);
            panel1.TabIndex = 38;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(232, 239, 253);
            button4.Dock = DockStyle.Top;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            button4.ForeColor = Color.FromArgb(12, 67, 122);
            button4.Image = Properties.Resources.perfil_azul_27;
            button4.Location = new Point(0, 819);
            button4.Name = "button4";
            button4.Padding = new Padding(20, 0, 0, 0);
            button4.Size = new Size(274, 124);
            button4.TabIndex = 8;
            button4.Text = "     Profile";
            button4.TextImageRelation = TextImageRelation.ImageBeforeText;
            button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(12, 67, 122);
            button3.Dock = DockStyle.Top;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Image = Properties.Resources.agendar_blanco_27;
            button3.Location = new Point(0, 695);
            button3.Name = "button3";
            button3.Padding = new Padding(20, 0, 0, 0);
            button3.Size = new Size(274, 124);
            button3.TabIndex = 7;
            button3.Text = "   Schedule";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(12, 67, 122);
            button2.Dock = DockStyle.Top;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Image = Properties.Resources.calendario_blanco_27;
            button2.Location = new Point(0, 571);
            button2.Name = "button2";
            button2.Padding = new Padding(20, 0, 0, 0);
            button2.Size = new Size(274, 124);
            button2.TabIndex = 6;
            button2.Text = "    Calender";
            button2.TextImageRelation = TextImageRelation.ImageBeforeText;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(12, 67, 122);
            button5.Dock = DockStyle.Top;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            button5.ForeColor = Color.White;
            button5.Image = Properties.Resources.inventario_blanca_27;
            button5.Location = new Point(0, 447);
            button5.Name = "button5";
            button5.Padding = new Padding(20, 0, 0, 0);
            button5.Size = new Size(274, 124);
            button5.TabIndex = 9;
            button5.Text = "    Inventory";
            button5.TextImageRelation = TextImageRelation.ImageBeforeText;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // Catalogo
            // 
            Catalogo.BackColor = Color.FromArgb(12, 67, 122);
            Catalogo.Dock = DockStyle.Top;
            Catalogo.FlatAppearance.BorderSize = 0;
            Catalogo.FlatStyle = FlatStyle.Flat;
            Catalogo.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Catalogo.ForeColor = Color.White;
            Catalogo.Image = Properties.Resources.catalogo_blanco_27;
            Catalogo.Location = new Point(0, 323);
            Catalogo.Name = "Catalogo";
            Catalogo.Padding = new Padding(20, 0, 0, 0);
            Catalogo.Size = new Size(274, 124);
            Catalogo.TabIndex = 5;
            Catalogo.Text = "    Catalog";
            Catalogo.TextImageRelation = TextImageRelation.ImageBeforeText;
            Catalogo.UseVisualStyleBackColor = false;
            Catalogo.Click += Catalogo_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(12, 67, 122);
            button1.Dock = DockStyle.Top;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Image = Properties.Resources.casa_blanca_27;
            button1.Location = new Point(0, 199);
            button1.Name = "button1";
            button1.Padding = new Padding(20, 0, 0, 0);
            button1.Size = new Size(274, 124);
            button1.TabIndex = 14;
            button1.Text = "    Home";
            button1.TextImageRelation = TextImageRelation.ImageBeforeText;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(label10);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(panel3);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(274, 199);
            panel2.TabIndex = 0;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label10.ForeColor = Color.White;
            label10.Location = new Point(24, 87);
            label10.Name = "label10";
            label10.Size = new Size(165, 47);
            label10.TabIndex = 7;
            label10.Text = "Planner";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Dock = DockStyle.Top;
            label11.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label11.ForeColor = Color.White;
            label11.Location = new Point(0, 0);
            label11.Name = "label11";
            label11.Padding = new Padding(30, 40, 0, 0);
            label11.Size = new Size(132, 87);
            label11.TabIndex = 6;
            label11.Text = "Petit";
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Dock = DockStyle.Right;
            panel3.Location = new Point(153, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(121, 199);
            panel3.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(121, 199);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.AutoScroll = true;
            panel4.BackColor = Color.FromArgb(232, 239, 253);
            panel4.Controls.Add(panelContenido);
            panel4.Controls.Add(panel5);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(300, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(995, 800);
            panel4.TabIndex = 39;
            // 
            // panelContenido
            // 
            panelContenido.Anchor = AnchorStyles.None;
            panelContenido.BackColor = Color.White;
            panelContenido.Controls.Add(panelPassword);
            panelContenido.Controls.Add(panelBusiness);
            panelContenido.Controls.Add(panelUser);
            panelContenido.Controls.Add(panelEmail);
            panelContenido.Controls.Add(button6);
            panelContenido.Location = new Point(152, 134);
            panelContenido.Name = "panelContenido";
            panelContenido.Size = new Size(600, 480);
            panelContenido.TabIndex = 41;
            // 
            // panelPassword
            // 
            panelPassword.BackColor = SystemColors.Control;
            panelPassword.BorderStyle = BorderStyle.FixedSingle;
            panelPassword.Controls.Add(passwordUser);
            panelPassword.Location = new Point(50, 267);
            panelPassword.Name = "panelPassword";
            panelPassword.Size = new Size(500, 50);
            panelPassword.TabIndex = 48;
            // 
            // passwordUser
            // 
            passwordUser.BackColor = SystemColors.Control;
            passwordUser.BorderStyle = BorderStyle.None;
            passwordUser.Font = new Font("Century Gothic", 9F);
            passwordUser.Location = new Point(13, 11);
            passwordUser.Name = "passwordUser";
            passwordUser.ScrollBars = RichTextBoxScrollBars.None;
            passwordUser.Size = new Size(470, 30);
            passwordUser.TabIndex = 12;
            passwordUser.Text = "";
            // 
            // panelBusiness
            // 
            panelBusiness.BackColor = SystemColors.Control;
            panelBusiness.BorderStyle = BorderStyle.FixedSingle;
            panelBusiness.Controls.Add(userBussinesName);
            panelBusiness.Location = new Point(50, 193);
            panelBusiness.Name = "panelBusiness";
            panelBusiness.Size = new Size(500, 50);
            panelBusiness.TabIndex = 46;
            // 
            // userBussinesName
            // 
            userBussinesName.BackColor = SystemColors.Control;
            userBussinesName.BorderStyle = BorderStyle.None;
            userBussinesName.Font = new Font("Century Gothic", 9F);
            userBussinesName.Location = new Point(13, 11);
            userBussinesName.Name = "userBussinesName";
            userBussinesName.ScrollBars = RichTextBoxScrollBars.None;
            userBussinesName.Size = new Size(470, 30);
            userBussinesName.TabIndex = 11;
            userBussinesName.Text = "";
            // 
            // panelUser
            // 
            panelUser.BackColor = SystemColors.Control;
            panelUser.BorderStyle = BorderStyle.FixedSingle;
            panelUser.Controls.Add(userName);
            panelUser.Location = new Point(50, 118);
            panelUser.Name = "panelUser";
            panelUser.Size = new Size(500, 50);
            panelUser.TabIndex = 44;
            // 
            // userName
            // 
            userName.BackColor = SystemColors.Control;
            userName.BorderStyle = BorderStyle.None;
            userName.Font = new Font("Century Gothic", 9F);
            userName.Location = new Point(13, 11);
            userName.Name = "userName";
            userName.ScrollBars = RichTextBoxScrollBars.None;
            userName.Size = new Size(470, 30);
            userName.TabIndex = 10;
            userName.Text = "";
            // 
            // panelEmail
            // 
            panelEmail.BackColor = SystemColors.Control;
            panelEmail.BorderStyle = BorderStyle.FixedSingle;
            panelEmail.Controls.Add(emailUser);
            panelEmail.Location = new Point(50, 41);
            panelEmail.Name = "panelEmail";
            panelEmail.Size = new Size(500, 50);
            panelEmail.TabIndex = 42;
            // 
            // emailUser
            // 
            emailUser.BackColor = SystemColors.Control;
            emailUser.BorderStyle = BorderStyle.None;
            emailUser.Font = new Font("Century Gothic", 9F);
            emailUser.Location = new Point(13, 11);
            emailUser.Name = "emailUser";
            emailUser.ScrollBars = RichTextBoxScrollBars.None;
            emailUser.Size = new Size(470, 30);
            emailUser.TabIndex = 9;
            emailUser.Text = "";
            // 
            // button6
            // 
            button6.BackColor = Color.Brown;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            button6.ForeColor = Color.White;
            button6.Location = new Point(50, 341);
            button6.Name = "button6";
            button6.Size = new Size(500, 50);
            button6.TabIndex = 13;
            button6.Text = "Log out";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(labelTitle);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(995, 100);
            panel5.TabIndex = 40;
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.Dock = DockStyle.Top;
            labelTitle.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            labelTitle.ForeColor = Color.FromArgb(12, 67, 122);
            labelTitle.Location = new Point(0, 0);
            labelTitle.Name = "labelTitle";
            labelTitle.Padding = new Padding(50, 24, 0, 0);
            labelTitle.Size = new Size(282, 71);
            labelTitle.TabIndex = 10;
            labelTitle.Text = "User Profile";
            // 
            // profile
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel4);
            Controls.Add(panel1);
            Name = "profile";
            Size = new Size(1295, 800);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panelContenido.ResumeLayout(false);
            panelPassword.ResumeLayout(false);
            panelBusiness.ResumeLayout(false);
            panelUser.ResumeLayout(false);
            panelEmail.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Catalogo; // NUEVA VARIABLE AÑADIDA
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.RichTextBox emailUser;
        private System.Windows.Forms.RichTextBox userName;
        private System.Windows.Forms.RichTextBox userBussinesName;
        private System.Windows.Forms.RichTextBox passwordUser;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panelEmail;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.Panel panelBusiness;
        private System.Windows.Forms.Panel panelUser;
    }
}