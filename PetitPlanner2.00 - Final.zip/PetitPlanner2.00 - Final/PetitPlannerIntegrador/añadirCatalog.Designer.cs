﻿namespace PetitPlannerIntegrador
{
    partial class añadirCatalog
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            catalogDataGridView = new DataGridView();
            añadir = new Button();
            editar = new Button();
            eliminar = new Button();
            backCatalog = new Button();
            panelActions = new Panel();
            panelHeader = new Panel();
            labelTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)catalogDataGridView).BeginInit();
            panelActions.SuspendLayout();
            panelHeader.SuspendLayout();
            SuspendLayout();
            // 
            // catalogDataGridView
            // 
            catalogDataGridView.AllowUserToResizeColumns = false;
            catalogDataGridView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            catalogDataGridView.BackgroundColor = Color.FromArgb(232, 239, 253);
            catalogDataGridView.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(48, 63, 159);
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = Color.White;
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            catalogDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            catalogDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.White;
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 9F);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            catalogDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            catalogDataGridView.EnableHeadersVisualStyles = false;
            catalogDataGridView.Location = new Point(30, 110);
            catalogDataGridView.Name = "catalogDataGridView";
            catalogDataGridView.RowHeadersWidth = 30;
            catalogDataGridView.Size = new Size(650, 410);
            catalogDataGridView.TabIndex = 0;
            // 
            // añadir
            // 
            añadir.BackColor = Color.FromArgb(12, 67, 122);
            añadir.FlatAppearance.BorderSize = 0;
            añadir.FlatStyle = FlatStyle.Flat;
            añadir.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            añadir.ForeColor = Color.White;
            añadir.Location = new Point(20, 20);
            añadir.Name = "añadir";
            añadir.Size = new Size(250, 60);
            añadir.TabIndex = 1;
            añadir.Text = "Add Article";
            añadir.UseVisualStyleBackColor = false;
            añadir.Click += añadir_Click;
            // 
            // editar
            // 
            editar.BackColor = Color.FromArgb(255, 193, 7);
            editar.FlatAppearance.BorderSize = 0;
            editar.FlatStyle = FlatStyle.Flat;
            editar.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            editar.ForeColor = Color.Black;
            editar.Location = new Point(20, 100);
            editar.Name = "editar";
            editar.Size = new Size(250, 60);
            editar.TabIndex = 2;
            editar.Text = "Edit Article";
            editar.UseVisualStyleBackColor = false;
            editar.Click += editar_Click;
            // 
            // eliminar
            // 
            eliminar.BackColor = Color.FromArgb(220, 53, 69);
            eliminar.FlatAppearance.BorderSize = 0;
            eliminar.FlatStyle = FlatStyle.Flat;
            eliminar.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            eliminar.ForeColor = Color.White;
            eliminar.Location = new Point(20, 180);
            eliminar.Name = "eliminar";
            eliminar.Size = new Size(250, 60);
            eliminar.TabIndex = 3;
            eliminar.Text = "Delete Article";
            eliminar.UseVisualStyleBackColor = false;
            eliminar.Click += eliminar_Click;
            // 
            // backCatalog
            // 
            backCatalog.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            backCatalog.BackColor = Color.FromArgb(48, 63, 159);
            backCatalog.FlatAppearance.BorderSize = 0;
            backCatalog.FlatStyle = FlatStyle.Flat;
            backCatalog.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            backCatalog.ForeColor = Color.White;
            backCatalog.Location = new Point(720, 22);
            backCatalog.Name = "backCatalog";
            backCatalog.Size = new Size(250, 50);
            backCatalog.TabIndex = 4;
            backCatalog.Text = "← BACK";
            backCatalog.UseVisualStyleBackColor = false;
            backCatalog.Click += backCatalog_Click;
            // 
            // panelActions
            // 
            panelActions.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panelActions.BackColor = Color.White;
            panelActions.Controls.Add(añadir);
            panelActions.Controls.Add(eliminar);
            panelActions.Controls.Add(editar);
            panelActions.Location = new Point(690, 110);
            panelActions.Name = "panelActions";
            panelActions.Size = new Size(290, 262);
            panelActions.TabIndex = 6;
            // 
            // panelHeader
            // 
            panelHeader.BackColor = Color.White;
            panelHeader.Controls.Add(labelTitle);
            panelHeader.Controls.Add(backCatalog);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Location = new Point(0, 0);
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(990, 91);
            panelHeader.TabIndex = 7;
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.BackColor = Color.White;
            labelTitle.Font = new Font("Century Gothic", 18F, FontStyle.Bold);
            labelTitle.ForeColor = Color.FromArgb(12, 67, 122);
            labelTitle.Location = new Point(30, 20);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(342, 43);
            labelTitle.TabIndex = 5;
            labelTitle.Text = "Manage Inventory";
            // 
            // añadirCatalog
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(232, 239, 253);
            Controls.Add(panelActions);
            Controls.Add(catalogDataGridView);
            Controls.Add(panelHeader);
            MinimumSize = new Size(800, 400);
            Name = "añadirCatalog";
            Size = new Size(990, 550);
            ((System.ComponentModel.ISupportInitialize)catalogDataGridView).EndInit();
            panelActions.ResumeLayout(false);
            panelHeader.ResumeLayout(false);
            panelHeader.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView catalogDataGridView;
        private Button añadir;
        private Button editar;
        private Button eliminar;
        private Button backCatalog;
        private Panel panelActions;
        private Panel panelHeader;
        private Label labelTitle;
    }
}