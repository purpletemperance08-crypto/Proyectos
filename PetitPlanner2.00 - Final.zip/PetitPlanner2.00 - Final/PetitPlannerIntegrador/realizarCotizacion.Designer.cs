﻿namespace PetitPlannerIntegrador
{
    partial class realizarCotizacion
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            dgvInventario = new DataGridView();
            dgvCarrito = new DataGridView();
            txtCantidad = new TextBox();
            btnAnadir = new Button();
            lblTotalCantidad = new Label();
            lblMontoFinal = new Label();
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            btnGuardarCotizacion = new Button();
            finalizarCoti = new Button();
            panelMain = new Panel();
            panelHeader = new Panel();
            labelTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvInventario).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCarrito).BeginInit();
            panelMain.SuspendLayout();
            panelHeader.SuspendLayout();
            SuspendLayout();
            // 
            // dgvInventario
            // 
            dgvInventario.AllowUserToAddRows = false;
            dgvInventario.AllowUserToResizeColumns = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(245, 245, 245);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(192, 219, 245);
            dataGridViewCellStyle1.SelectionForeColor = Color.Black;
            dgvInventario.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvInventario.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            dgvInventario.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvInventario.BackgroundColor = Color.White;
            dgvInventario.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvInventario.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvInventario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Century Gothic", 9F);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(192, 219, 245);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgvInventario.DefaultCellStyle = dataGridViewCellStyle3;
            dgvInventario.EnableHeadersVisualStyles = false;
            dgvInventario.GridColor = Color.FromArgb(220, 220, 220);
            dgvInventario.Location = new Point(35, 120);
            dgvInventario.Name = "dgvInventario";
            dgvInventario.RowHeadersVisible = false;
            dgvInventario.RowHeadersWidth = 62;
            dgvInventario.Size = new Size(550, 424);
            dgvInventario.TabIndex = 0;
            // 
            // dgvCarrito
            // 
            dgvCarrito.AllowUserToAddRows = false;
            dgvCarrito.AllowUserToResizeColumns = false;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(245, 245, 245);
            dataGridViewCellStyle4.ForeColor = Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(192, 219, 245);
            dataGridViewCellStyle4.SelectionForeColor = Color.Black;
            dgvCarrito.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dgvCarrito.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvCarrito.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCarrito.BackgroundColor = Color.White;
            dgvCarrito.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle5.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.SelectionBackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            dgvCarrito.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dgvCarrito.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Century Gothic", 9F);
            dataGridViewCellStyle6.ForeColor = Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(192, 219, 245);
            dataGridViewCellStyle6.SelectionForeColor = Color.Black;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            dgvCarrito.DefaultCellStyle = dataGridViewCellStyle6;
            dgvCarrito.EnableHeadersVisualStyles = false;
            dgvCarrito.GridColor = Color.FromArgb(220, 220, 220);
            dgvCarrito.Location = new Point(610, 120);
            dgvCarrito.Name = "dgvCarrito";
            dgvCarrito.RowHeadersVisible = false;
            dgvCarrito.RowHeadersWidth = 62;
            dgvCarrito.Size = new Size(598, 424);
            dgvCarrito.TabIndex = 1;
            // 
            // txtCantidad
            // 
            txtCantidad.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            txtCantidad.BorderStyle = BorderStyle.FixedSingle;
            txtCantidad.Font = new Font("Century Gothic", 10F);
            txtCantidad.Location = new Point(35, 594);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(313, 32);
            txtCantidad.TabIndex = 2;
            // 
            // btnAnadir
            // 
            btnAnadir.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnAnadir.BackColor = Color.LimeGreen;
            btnAnadir.FlatAppearance.BorderSize = 0;
            btnAnadir.FlatStyle = FlatStyle.Flat;
            btnAnadir.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            btnAnadir.ForeColor = Color.White;
            btnAnadir.Location = new Point(370, 588);
            btnAnadir.Name = "btnAnadir";
            btnAnadir.Size = new Size(160, 44);
            btnAnadir.TabIndex = 3;
            btnAnadir.Text = "Add";
            btnAnadir.UseVisualStyleBackColor = false;
            // 
            // lblTotalCantidad
            // 
            lblTotalCantidad.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblTotalCantidad.AutoSize = true;
            lblTotalCantidad.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            lblTotalCantidad.ForeColor = Color.FromArgb(12, 67, 122);
            lblTotalCantidad.Location = new Point(610, 600);
            lblTotalCantidad.Name = "lblTotalCantidad";
            lblTotalCantidad.Size = new Size(24, 26);
            lblTotalCantidad.TabIndex = 4;
            lblTotalCantidad.Text = "0";
            // 
            // lblMontoFinal
            // 
            lblMontoFinal.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblMontoFinal.AutoSize = true;
            lblMontoFinal.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            lblMontoFinal.ForeColor = Color.FromArgb(12, 67, 122);
            lblMontoFinal.Location = new Point(820, 600);
            lblMontoFinal.Name = "lblMontoFinal";
            lblMontoFinal.Size = new Size(66, 26);
            lblMontoFinal.TabIndex = 5;
            lblMontoFinal.Text = "$0.00";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F);
            label1.Location = new Point(35, 564);
            label1.Name = "label1";
            label1.Size = new Size(300, 21);
            label1.TabIndex = 6;
            label1.Text = "Ingrese la cantidad del producto";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 9F);
            label2.Location = new Point(610, 564);
            label2.Name = "label2";
            label2.Size = new Size(52, 21);
            label2.TabIndex = 7;
            label2.Text = "Total";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 9F);
            label4.Location = new Point(820, 564);
            label4.Name = "label4";
            label4.Size = new Size(201, 21);
            label4.TabIndex = 9;
            label4.Text = "Total de la Cotizacion";
            // 
            // btnGuardarCotizacion
            // 
            btnGuardarCotizacion.Location = new Point(0, 0);
            btnGuardarCotizacion.Name = "btnGuardarCotizacion";
            btnGuardarCotizacion.Size = new Size(75, 23);
            btnGuardarCotizacion.TabIndex = 0;
            btnGuardarCotizacion.Visible = false;
            // 
            // finalizarCoti
            // 
            finalizarCoti.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            finalizarCoti.BackColor = Color.FromArgb(12, 67, 122);
            finalizarCoti.FlatAppearance.BorderSize = 0;
            finalizarCoti.FlatStyle = FlatStyle.Flat;
            finalizarCoti.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            finalizarCoti.ForeColor = Color.White;
            finalizarCoti.Location = new Point(1008, 594);
            finalizarCoti.Name = "finalizarCoti";
            finalizarCoti.Size = new Size(200, 38);
            finalizarCoti.TabIndex = 10;
            finalizarCoti.Text = "Finish";
            finalizarCoti.UseVisualStyleBackColor = false;
            finalizarCoti.Click += finalizarCoti_Click;
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.FromArgb(232, 239, 253);
            panelMain.Controls.Add(panelHeader);
            panelMain.Controls.Add(dgvInventario);
            panelMain.Controls.Add(dgvCarrito);
            panelMain.Controls.Add(finalizarCoti);
            panelMain.Controls.Add(txtCantidad);
            panelMain.Controls.Add(label4);
            panelMain.Controls.Add(btnAnadir);
            panelMain.Controls.Add(label2);
            panelMain.Controls.Add(lblTotalCantidad);
            panelMain.Controls.Add(label1);
            panelMain.Controls.Add(lblMontoFinal);
            panelMain.Dock = DockStyle.Fill;
            panelMain.Location = new Point(0, 0);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(1242, 664);
            panelMain.TabIndex = 11;
            // 
            // panelHeader
            // 
            panelHeader.BackColor = Color.White;
            panelHeader.Controls.Add(labelTitle);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Location = new Point(0, 0);
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(1242, 96);
            panelHeader.TabIndex = 12;
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.Dock = DockStyle.Top;
            labelTitle.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            labelTitle.ForeColor = Color.FromArgb(12, 67, 122);
            labelTitle.Location = new Point(0, 0);
            labelTitle.Name = "labelTitle";
            labelTitle.Padding = new Padding(50, 24, 0, 0);
            labelTitle.Size = new Size(442, 71);
            labelTitle.TabIndex = 7;
            labelTitle.Text = "Realizar Cotización";
            // 
            // realizarCotizacion
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1242, 664);
            Controls.Add(panelMain);
            Controls.Add(btnGuardarCotizacion);
            Name = "realizarCotizacion";
            ((System.ComponentModel.ISupportInitialize)dgvInventario).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCarrito).EndInit();
            panelMain.ResumeLayout(false);
            panelMain.PerformLayout();
            panelHeader.ResumeLayout(false);
            panelHeader.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataGridView dgvInventario;
        private System.Windows.Forms.DataGridView dgvCarrito;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.Button btnAnadir;
        private System.Windows.Forms.Label lblTotalCantidad;
        private System.Windows.Forms.Label lblMontoFinal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnGuardarCotizacion;
        private System.Windows.Forms.Button finalizarCoti;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label labelTitle;
    }
}