﻿namespace PetitPlannerIntegrador
{
    partial class LoginControl
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox textBoxUsuario;
        private TextBox textBoxPassword;
        private Button button1;
        private Label label1;
        private Label label2;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            textBoxUsuario = new TextBox();
            textBoxPassword = new TextBox();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            createAccount = new LinkLabel();
            splitContainer1 = new SplitContainer();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            pictureBox4 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            incorrectUser = new Label();
            label5 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            panel3 = new Panel();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // textBoxUsuario
            // 
            textBoxUsuario.BackColor = Color.Gainsboro;
            textBoxUsuario.BorderStyle = BorderStyle.None;
            textBoxUsuario.Location = new Point(43, 5);
            textBoxUsuario.Margin = new Padding(4, 5, 4, 5);
            textBoxUsuario.Name = "textBoxUsuario";
            textBoxUsuario.Size = new Size(263, 24);
            textBoxUsuario.TabIndex = 0;
            // 
            // textBoxPassword
            // 
            textBoxPassword.BackColor = Color.Gainsboro;
            textBoxPassword.BorderStyle = BorderStyle.None;
            textBoxPassword.Location = new Point(43, 9);
            textBoxPassword.Margin = new Padding(4, 5, 4, 5);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.PasswordChar = '*';
            textBoxPassword.Size = new Size(263, 24);
            textBoxPassword.TabIndex = 1;
            textBoxPassword.TextChanged += textBoxPassword_TextChanged;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.None;
            button1.BackColor = Color.FromArgb(12, 67, 122);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(235, 381);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(316, 61);
            button1.TabIndex = 2;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            label1.Location = new Point(235, 181);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(48, 22);
            label1.TabIndex = 3;
            label1.Text = "User";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            label2.Location = new Point(235, 274);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(92, 22);
            label2.TabIndex = 4;
            label2.Text = "Password";
            // 
            // createAccount
            // 
            createAccount.Anchor = AnchorStyles.None;
            createAccount.AutoSize = true;
            createAccount.Font = new Font("Segoe UI", 7F);
            createAccount.LinkColor = Color.FromArgb(64, 64, 64);
            createAccount.Location = new Point(295, 456);
            createAccount.Name = "createAccount";
            createAccount.Size = new Size(250, 19);
            createAccount.TabIndex = 5;
            createAccount.TabStop = true;
            createAccount.Text = "Don´t have an account? Create account";
            createAccount.LinkClicked += createAccount_LinkClicked;
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.FromArgb(12, 67, 122);
            splitContainer1.Panel1.Controls.Add(pictureBox1);
            splitContainer1.Panel1.Controls.Add(panel1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.BackColor = Color.White;
            splitContainer1.Panel2.Controls.Add(incorrectUser);
            splitContainer1.Panel2.Controls.Add(label5);
            splitContainer1.Panel2.Controls.Add(label1);
            splitContainer1.Panel2.Controls.Add(label2);
            splitContainer1.Panel2.Controls.Add(createAccount);
            splitContainer1.Panel2.Controls.Add(button1);
            splitContainer1.Panel2.Controls.Add(panel2);
            splitContainer1.Panel2.Controls.Add(panel3);
            splitContainer1.Size = new Size(1201, 620);
            splitContainer1.SplitterDistance = 400;
            splitContainer1.TabIndex = 6;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 235);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(400, 385);
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label4);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(400, 235);
            panel1.TabIndex = 2;
            // 
            // pictureBox4
            // 
            pictureBox4.Anchor = AnchorStyles.None;
            pictureBox4.Location = new Point(226, 45);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(91, 80);
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 30F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(84, 45);
            label3.Name = "label3";
            label3.Size = new Size(152, 70);
            label3.TabIndex = 0;
            label3.Text = "Petit";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 30F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(84, 115);
            label4.Name = "label4";
            label4.Size = new Size(247, 70);
            label4.TabIndex = 1;
            label4.Text = "Planner";
            // 
            // incorrectUser
            // 
            incorrectUser.Anchor = AnchorStyles.None;
            incorrectUser.AutoSize = true;
            incorrectUser.BackColor = Color.Transparent;
            incorrectUser.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            incorrectUser.ForeColor = Color.DarkRed;
            incorrectUser.Location = new Point(239, 354);
            incorrectUser.Margin = new Padding(4, 0, 4, 0);
            incorrectUser.Name = "incorrectUser";
            incorrectUser.Size = new Size(0, 22);
            incorrectUser.TabIndex = 10;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label5.Location = new Point(235, 115);
            label5.Name = "label5";
            label5.Size = new Size(237, 34);
            label5.TabIndex = 6;
            label5.Text = "Welcome Back!!";
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox2);
            panel2.Controls.Add(textBoxUsuario);
            panel2.Location = new Point(235, 216);
            panel2.Name = "panel2";
            panel2.Size = new Size(310, 38);
            panel2.TabIndex = 7;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.user_icon;
            pictureBox2.Location = new Point(4, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(32, 34);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.None;
            panel3.BackColor = Color.Gainsboro;
            panel3.Controls.Add(pictureBox3);
            panel3.Controls.Add(textBoxPassword);
            panel3.Location = new Point(235, 308);
            panel3.Name = "panel3";
            panel3.Size = new Size(310, 38);
            panel3.TabIndex = 8;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.password_icon;
            pictureBox3.Location = new Point(4, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(32, 34);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // LoginControl
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(splitContainer1);
            Margin = new Padding(4, 5, 4, 5);
            MinimumSize = new Size(890, 450);
            Name = "LoginControl";
            Size = new Size(1201, 620);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        private LinkLabel createAccount;
        private SplitContainer splitContainer1;
        private Panel panel1;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox1;
        private Panel panel3;
        private Label label5;
        private Panel panel2;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label incorrectUser;
    }
}