﻿namespace PetitPlannerIntegrador
{
    partial class CreateAccountControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            create = new Button();
            user = new Label();
            password = new Label();
            gmail = new Label();
            textBoxUsuario = new TextBox();
            textBoxPassword = new TextBox();
            textBoxGmail = new TextBox();
            textBoxPasswordConfirm = new TextBox();
            label1 = new Label();
            volver = new Button();
            splitContainer1 = new SplitContainer();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            label3 = new Label();
            label2 = new Label();
            label5 = new Label();
            panel6 = new Panel();
            pictureBox7 = new PictureBox();
            textBoxNombreNegocio = new TextBox();
            label4 = new Label();
            panel5 = new Panel();
            pictureBox6 = new PictureBox();
            panel4 = new Panel();
            pictureBox5 = new PictureBox();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            panel3 = new Panel();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // create
            // 
            create.Anchor = AnchorStyles.None;
            create.BackColor = Color.FromArgb(48, 63, 159);
            create.FlatAppearance.BorderSize = 0;
            create.FlatStyle = FlatStyle.Flat;
            create.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            create.ForeColor = Color.White;
            create.Location = new Point(235, 486);
            create.Name = "create";
            create.Size = new Size(316, 61);
            create.TabIndex = 0;
            create.Text = "Create Account";
            create.UseVisualStyleBackColor = false;
            create.Click += create_Click;
            // 
            // user
            // 
            user.Anchor = AnchorStyles.None;
            user.AutoSize = true;
            user.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            user.Location = new Point(235, 90);
            user.Name = "user";
            user.Size = new Size(48, 22);
            user.TabIndex = 1;
            user.Text = "User";
            // 
            // password
            // 
            password.Anchor = AnchorStyles.None;
            password.AutoSize = true;
            password.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            password.Location = new Point(235, 165);
            password.Name = "password";
            password.Size = new Size(141, 22);
            password.TabIndex = 2;
            password.Text = "Bussines Name";
            // 
            // gmail
            // 
            gmail.Anchor = AnchorStyles.None;
            gmail.AutoSize = true;
            gmail.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            gmail.Location = new Point(235, 401);
            gmail.Name = "gmail";
            gmail.Size = new Size(62, 22);
            gmail.TabIndex = 3;
            gmail.Text = "Gmail";
            // 
            // textBoxUsuario
            // 
            textBoxUsuario.BackColor = Color.Gainsboro;
            textBoxUsuario.BorderStyle = BorderStyle.None;
            textBoxUsuario.Location = new Point(43, 3);
            textBoxUsuario.Name = "textBoxUsuario";
            textBoxUsuario.Size = new Size(263, 24);
            textBoxUsuario.TabIndex = 4;
            // 
            // textBoxPassword
            // 
            textBoxPassword.BackColor = Color.Gainsboro;
            textBoxPassword.BorderStyle = BorderStyle.None;
            textBoxPassword.Location = new Point(42, 11);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.PasswordChar = '*';
            textBoxPassword.Size = new Size(263, 24);
            textBoxPassword.TabIndex = 5;
            // 
            // textBoxGmail
            // 
            textBoxGmail.BackColor = Color.Gainsboro;
            textBoxGmail.BorderStyle = BorderStyle.None;
            textBoxGmail.Location = new Point(43, 5);
            textBoxGmail.Name = "textBoxGmail";
            textBoxGmail.Size = new Size(263, 24);
            textBoxGmail.TabIndex = 6;
            // 
            // textBoxPasswordConfirm
            // 
            textBoxPasswordConfirm.BackColor = Color.Gainsboro;
            textBoxPasswordConfirm.BorderStyle = BorderStyle.None;
            textBoxPasswordConfirm.Location = new Point(43, 5);
            textBoxPasswordConfirm.Name = "textBoxPasswordConfirm";
            textBoxPasswordConfirm.PasswordChar = '*';
            textBoxPasswordConfirm.Size = new Size(263, 24);
            textBoxPasswordConfirm.TabIndex = 7;
            textBoxPasswordConfirm.TextChanged += textBoxPasswordConfirm_TextChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            label1.Location = new Point(235, 321);
            label1.Name = "label1";
            label1.Size = new Size(166, 22);
            label1.TabIndex = 8;
            label1.Text = "Confirm Password";
            label1.Click += label1_Click;
            // 
            // volver
            // 
            volver.Anchor = AnchorStyles.None;
            volver.BackColor = Color.FromArgb(12, 67, 122);
            volver.FlatAppearance.BorderSize = 0;
            volver.FlatStyle = FlatStyle.Flat;
            volver.Font = new Font("Century Gothic", 11F, FontStyle.Bold);
            volver.ForeColor = Color.White;
            volver.Image = Properties.Resources.icons8_flecha_21;
            volver.Location = new Point(235, 560);
            volver.Name = "volver";
            volver.Padding = new Padding(60, 0, 0, 0);
            volver.Size = new Size(316, 61);
            volver.TabIndex = 9;
            volver.Text = "  Login";
            volver.TextImageRelation = TextImageRelation.ImageBeforeText;
            volver.UseVisualStyleBackColor = false;
            volver.Click += volver_Click;
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.FromArgb(12, 67, 122);
            splitContainer1.Panel1.Controls.Add(pictureBox1);
            splitContainer1.Panel1.Controls.Add(panel1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(label5);
            splitContainer1.Panel2.Controls.Add(panel6);
            splitContainer1.Panel2.Controls.Add(label4);
            splitContainer1.Panel2.Controls.Add(panel5);
            splitContainer1.Panel2.Controls.Add(panel4);
            splitContainer1.Panel2.Controls.Add(volver);
            splitContainer1.Panel2.Controls.Add(user);
            splitContainer1.Panel2.Controls.Add(create);
            splitContainer1.Panel2.Controls.Add(gmail);
            splitContainer1.Panel2.Controls.Add(label1);
            splitContainer1.Panel2.Controls.Add(password);
            splitContainer1.Panel2.Controls.Add(panel2);
            splitContainer1.Panel2.Controls.Add(panel3);
            splitContainer1.Panel2.Paint += splitContainer1_Panel2_Paint;
            splitContainer1.Size = new Size(1201, 620);
            splitContainer1.SplitterDistance = 400;
            splitContainer1.TabIndex = 10;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(48, 63, 159);
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 246);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(400, 374);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(48, 63, 159);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(400, 246);
            panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(213, 60);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(89, 73);
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 30F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(64, 130);
            label3.Name = "label3";
            label3.Size = new Size(247, 70);
            label3.TabIndex = 1;
            label3.Text = "Planner";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 30F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(64, 60);
            label2.Name = "label2";
            label2.Size = new Size(152, 70);
            label2.TabIndex = 0;
            label2.Text = "Petit";
            label2.Click += label2_Click;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            label5.Location = new Point(235, 239);
            label5.Name = "label5";
            label5.Size = new Size(92, 22);
            label5.TabIndex = 17;
            label5.Text = "Password";
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.None;
            panel6.BackColor = Color.Gainsboro;
            panel6.Controls.Add(pictureBox7);
            panel6.Controls.Add(textBoxNombreNegocio);
            panel6.Location = new Point(235, 190);
            panel6.Name = "panel6";
            panel6.Size = new Size(316, 38);
            panel6.TabIndex = 16;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.password_icon;
            pictureBox7.Location = new Point(4, 4);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(32, 32);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 15;
            pictureBox7.TabStop = false;
            // 
            // textBoxNombreNegocio
            // 
            textBoxNombreNegocio.BackColor = Color.Gainsboro;
            textBoxNombreNegocio.BorderStyle = BorderStyle.None;
            textBoxNombreNegocio.Location = new Point(42, 11);
            textBoxNombreNegocio.Name = "textBoxNombreNegocio";
            textBoxNombreNegocio.Size = new Size(263, 24);
            textBoxNombreNegocio.TabIndex = 5;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 14F, FontStyle.Bold);
            label4.Location = new Point(235, 47);
            label4.Name = "label4";
            label4.Size = new Size(230, 34);
            label4.TabIndex = 14;
            label4.Text = "Create account";
            // 
            // panel5
            // 
            panel5.Anchor = AnchorStyles.None;
            panel5.BackColor = Color.Gainsboro;
            panel5.Controls.Add(pictureBox6);
            panel5.Controls.Add(textBoxGmail);
            panel5.Location = new Point(235, 426);
            panel5.Name = "panel5";
            panel5.Size = new Size(316, 38);
            panel5.TabIndex = 13;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.email_icon;
            pictureBox6.Location = new Point(4, 4);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(32, 34);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 15;
            pictureBox6.TabStop = false;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.None;
            panel4.BackColor = Color.Gainsboro;
            panel4.Controls.Add(pictureBox5);
            panel4.Controls.Add(textBoxPasswordConfirm);
            panel4.Location = new Point(235, 346);
            panel4.Name = "panel4";
            panel4.Size = new Size(316, 38);
            panel4.TabIndex = 12;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.key_icon;
            pictureBox5.Location = new Point(4, 4);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(32, 34);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 15;
            pictureBox5.TabStop = false;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(textBoxUsuario);
            panel2.Location = new Point(235, 115);
            panel2.Name = "panel2";
            panel2.Size = new Size(316, 38);
            panel2.TabIndex = 10;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.user_icon;
            pictureBox3.Location = new Point(3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(32, 34);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.None;
            panel3.BackColor = Color.Gainsboro;
            panel3.Controls.Add(pictureBox4);
            panel3.Controls.Add(textBoxPassword);
            panel3.Location = new Point(235, 264);
            panel3.Name = "panel3";
            panel3.Size = new Size(316, 38);
            panel3.TabIndex = 11;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.password_icon;
            pictureBox4.Location = new Point(4, 4);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(32, 32);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 15;
            pictureBox4.TabStop = false;
            // 
            // CreateAccountControl
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(splitContainer1);
            Name = "CreateAccountControl";
            Size = new Size(1201, 620);
            Load += CreateAccountControl_Load;
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button create;
        private Label user;
        private Label password;
        private Label gmail;
        private TextBox textBoxUsuario;
        private TextBox textBoxPassword;
        private TextBox textBoxGmail;
        private TextBox textBoxPasswordConfirm;
        private Label label1;
        private Button volver;
        private SplitContainer splitContainer1;
        private Panel panel1;
        private Label label3;
        private Label label2;
        private Panel panel5;
        private Panel panel4;
        private Panel panel2;
        private Panel panel3;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private Label label4;
        private Label label5;
        private Panel panel6;
        private PictureBox pictureBox7;
        private TextBox textBoxNombreNegocio;
    }
}