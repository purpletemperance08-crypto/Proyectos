﻿namespace PetitPlannerIntegrador
{
    partial class inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            dataGridView1 = new DataGridView();
            añadirArticulo = new Button();
            productRepositorieBindingSource = new BindingSource(components);
            productRepositorieBindingSource1 = new BindingSource(components);
            panel1 = new Panel();
            profile = new Button();
            agendar = new Button();
            calendario = new Button();
            catalogo = new Button();
            Inventario = new Button();
            Home = new Button();
            panel2 = new Panel();
            label3 = new Label();
            label1 = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            panel5 = new Panel();
            label2 = new Label();
            inventoryId = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)productRepositorieBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)productRepositorieBindingSource1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(245, 245, 245);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(192, 219, 245);
            dataGridViewCellStyle1.SelectionForeColor = Color.Black;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(12, 67, 122);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Century Gothic", 9F);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(192, 219, 245);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = Color.FromArgb(220, 220, 220);
            dataGridView1.Location = new Point(64, 117);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(793, 412);
            dataGridView1.TabIndex = 9;
            // 
            // añadirArticulo
            // 
            añadirArticulo.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            añadirArticulo.BackColor = Color.LimeGreen;
            añadirArticulo.FlatAppearance.BorderSize = 0;
            añadirArticulo.FlatStyle = FlatStyle.Flat;
            añadirArticulo.Font = new Font("Century Gothic", 8F, FontStyle.Bold);
            añadirArticulo.ForeColor = Color.White;
            añadirArticulo.Location = new Point(71, 551);
            añadirArticulo.Name = "añadirArticulo";
            añadirArticulo.Padding = new Padding(15, 0, 0, 0);
            añadirArticulo.Size = new Size(300, 58);
            añadirArticulo.TabIndex = 8;
            añadirArticulo.Text = "Manager Articles";
            añadirArticulo.TextImageRelation = TextImageRelation.ImageBeforeText;
            añadirArticulo.UseVisualStyleBackColor = false;
            añadirArticulo.Click += añadirArticulo_Click_1;
            // 
            // productRepositorieBindingSource
            // 
            productRepositorieBindingSource.DataSource = typeof(ProductRepositorie);
            // 
            // productRepositorieBindingSource1
            // 
            productRepositorieBindingSource1.DataSource = typeof(ProductRepositorie);
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.FromArgb(12, 67, 122);
            panel1.Controls.Add(profile);
            panel1.Controls.Add(agendar);
            panel1.Controls.Add(calendario);
            panel1.Controls.Add(catalogo);
            panel1.Controls.Add(Inventario);
            panel1.Controls.Add(Home);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 634);
            panel1.TabIndex = 15;
            // 
            // profile
            // 
            profile.BackColor = Color.FromArgb(12, 67, 122);
            profile.Dock = DockStyle.Top;
            profile.FlatAppearance.BorderSize = 0;
            profile.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            profile.FlatStyle = FlatStyle.Flat;
            profile.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            profile.ForeColor = Color.White;
            profile.Image = Properties.Resources.perfil_blanco_27;
            profile.Location = new Point(0, 819);
            profile.Name = "profile";
            profile.Padding = new Padding(22, 0, 0, 0);
            profile.Size = new Size(274, 124);
            profile.TabIndex = 3;
            profile.Text = "    Profile";
            profile.TextImageRelation = TextImageRelation.ImageBeforeText;
            profile.UseVisualStyleBackColor = false;
            profile.Click += button1_Click;
            // 
            // agendar
            // 
            agendar.BackColor = Color.FromArgb(12, 67, 122);
            agendar.Dock = DockStyle.Top;
            agendar.FlatAppearance.BorderSize = 0;
            agendar.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            agendar.FlatStyle = FlatStyle.Flat;
            agendar.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            agendar.ForeColor = Color.White;
            agendar.Image = Properties.Resources.agendar_blanco_27;
            agendar.Location = new Point(0, 695);
            agendar.Name = "agendar";
            agendar.Padding = new Padding(30, 0, 0, 0);
            agendar.Size = new Size(274, 124);
            agendar.TabIndex = 2;
            agendar.Text = "   Schedule";
            agendar.TextImageRelation = TextImageRelation.ImageBeforeText;
            agendar.UseVisualStyleBackColor = false;
            agendar.Click += agendar_Click;
            // 
            // calendario
            // 
            calendario.BackColor = Color.FromArgb(12, 67, 122);
            calendario.Dock = DockStyle.Top;
            calendario.FlatAppearance.BorderSize = 0;
            calendario.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            calendario.FlatStyle = FlatStyle.Flat;
            calendario.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            calendario.ForeColor = Color.White;
            calendario.Image = Properties.Resources.calendario_blanco_27;
            calendario.Location = new Point(0, 571);
            calendario.Name = "calendario";
            calendario.Padding = new Padding(32, 0, 0, 0);
            calendario.Size = new Size(274, 124);
            calendario.TabIndex = 1;
            calendario.Text = "    Calender";
            calendario.TextImageRelation = TextImageRelation.ImageBeforeText;
            calendario.UseVisualStyleBackColor = false;
            calendario.Click += calendario_Click;
            // 
            // catalogo
            // 
            catalogo.BackColor = Color.FromArgb(12, 67, 122);
            catalogo.Dock = DockStyle.Top;
            catalogo.FlatAppearance.BorderSize = 0;
            catalogo.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            catalogo.FlatStyle = FlatStyle.Flat;
            catalogo.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            catalogo.ForeColor = Color.White;
            catalogo.Image = Properties.Resources.inventario_blanca_27;
            catalogo.Location = new Point(0, 447);
            catalogo.Name = "catalogo";
            catalogo.Padding = new Padding(22, 0, 0, 0);
            catalogo.Size = new Size(274, 124);
            catalogo.TabIndex = 2;
            catalogo.Text = "  Inventory";
            catalogo.TextImageRelation = TextImageRelation.ImageBeforeText;
            catalogo.UseVisualStyleBackColor = false;
            catalogo.Click += catalogo_Click;
            // 
            // Inventario
            // 
            Inventario.BackColor = Color.FromArgb(232, 239, 253);
            Inventario.Dock = DockStyle.Top;
            Inventario.FlatAppearance.BorderSize = 0;
            Inventario.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Inventario.FlatStyle = FlatStyle.Flat;
            Inventario.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Inventario.ForeColor = Color.FromArgb(12, 67, 122);
            Inventario.Image = Properties.Resources.catalogo_azul_27;
            Inventario.Location = new Point(0, 323);
            Inventario.Name = "Inventario";
            Inventario.Padding = new Padding(28, 0, 0, 0);
            Inventario.Size = new Size(274, 124);
            Inventario.TabIndex = 0;
            Inventario.Text = "  Catalog";
            Inventario.TextImageRelation = TextImageRelation.ImageBeforeText;
            Inventario.UseVisualStyleBackColor = false;
            // 
            // Home
            // 
            Home.BackColor = Color.FromArgb(12, 67, 122);
            Home.Dock = DockStyle.Top;
            Home.FlatAppearance.BorderSize = 0;
            Home.FlatAppearance.MouseOverBackColor = Color.FromArgb(86, 126, 156);
            Home.FlatStyle = FlatStyle.Flat;
            Home.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            Home.ForeColor = Color.White;
            Home.Image = Properties.Resources.casa_blanca_27;
            Home.Location = new Point(0, 199);
            Home.Name = "Home";
            Home.Padding = new Padding(22, 0, 0, 0);
            Home.Size = new Size(274, 124);
            Home.TabIndex = 4;
            Home.Text = "   Home";
            Home.TextImageRelation = TextImageRelation.ImageBeforeText;
            Home.UseVisualStyleBackColor = false;
            Home.Click += homePage_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(panel3);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(274, 199);
            panel2.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(24, 87);
            label3.Name = "label3";
            label3.Size = new Size(165, 47);
            label3.TabIndex = 7;
            label3.Text = "Planner";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Century Gothic", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Padding = new Padding(30, 40, 0, 0);
            label1.Size = new Size(132, 87);
            label1.TabIndex = 6;
            label1.Text = "Petit";
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Dock = DockStyle.Right;
            panel3.Location = new Point(153, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(121, 199);
            panel3.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(121, 199);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(232, 239, 253);
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(dataGridView1);
            panel4.Controls.Add(añadirArticulo);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(300, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(964, 634);
            panel4.TabIndex = 16;
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(label2);
            panel5.Controls.Add(inventoryId);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(964, 96);
            panel5.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(12, 67, 122);
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Padding = new Padding(50, 24, 0, 0);
            label2.Size = new Size(227, 71);
            label2.TabIndex = 7;
            label2.Text = "Catalog";
            // 
            // inventoryId
            // 
            inventoryId.AutoSize = true;
            inventoryId.Font = new Font("Century Gothic", 20F, FontStyle.Bold);
            inventoryId.ForeColor = Color.White;
            inventoryId.Location = new Point(699, 20);
            inventoryId.Name = "inventoryId";
            inventoryId.Padding = new Padding(30, 0, 0, 20);
            inventoryId.Size = new Size(244, 67);
            inventoryId.TabIndex = 6;
            inventoryId.Text = "Inventario";
            // 
            // inventory
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel4);
            Controls.Add(panel1);
            Name = "inventory";
            Size = new Size(1264, 634);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)productRepositorieBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)productRepositorieBindingSource1).EndInit();
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);

        }

        #endregion

        private DataGridView dataGridView1;
        private Button añadirArticulo;
        private BindingSource productRepositorieBindingSource;
        private BindingSource productRepositorieBindingSource1;
        private Panel panel1;
        private Panel panel2;
        private Label label3;
        private Label label1;
        private Panel panel3;
        private PictureBox pictureBox1;
        private Button profile;
        private Button agendar;
        private Button calendario;
        private Button Inventario;
        private Button Home;
        private Panel panel4;
        private Panel panel5;
        private Label label2;
        private Label inventoryId;
        private Button catalogo;
    }
}