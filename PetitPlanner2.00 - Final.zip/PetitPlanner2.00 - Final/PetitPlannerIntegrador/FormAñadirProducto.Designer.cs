﻿namespace PetitPlannerIntegrador
{
    partial class FormAñadirProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGuardar = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBoxPrice = new TextBox();
            textBoxDescription = new TextBox();
            textBoxName = new TextBox();
            panel1 = new Panel();
            btnCancelar = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(12, 67, 122);
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            btnGuardar.ForeColor = Color.White;
            btnGuardar.Location = new Point(19, 308);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(160, 60);
            btnGuardar.TabIndex = 13;
            btnGuardar.Text = "Add Articulo";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            label3.Location = new Point(172, 292);
            label3.Name = "label3";
            label3.Size = new Size(54, 22);
            label3.TabIndex = 12;
            label3.Text = "Price";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            label2.Location = new Point(172, 196);
            label2.Name = "label2";
            label2.Size = new Size(109, 22);
            label2.TabIndex = 11;
            label2.Text = "Description";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Century Gothic", 9F, FontStyle.Bold);
            label1.Location = new Point(172, 110);
            label1.Name = "label1";
            label1.Size = new Size(64, 22);
            label1.TabIndex = 10;
            label1.Text = "Name";
            // 
            // textBoxPrice
            // 
            textBoxPrice.Location = new Point(172, 332);
            textBoxPrice.Name = "textBoxPrice";
            textBoxPrice.Size = new Size(311, 31);
            textBoxPrice.TabIndex = 9;
            // 
            // textBoxDescription
            // 
            textBoxDescription.Location = new Point(172, 236);
            textBoxDescription.Name = "textBoxDescription";
            textBoxDescription.Size = new Size(311, 31);
            textBoxDescription.TabIndex = 8;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(172, 144);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(311, 31);
            textBoxName.TabIndex = 7;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(btnCancelar);
            panel1.Controls.Add(btnGuardar);
            panel1.Location = new Point(145, 86);
            panel1.Name = "panel1";
            panel1.Size = new Size(372, 426);
            panel1.TabIndex = 14;
            // 
            // btnCancelar
            // 
            btnCancelar.BackColor = Color.Gray;
            btnCancelar.FlatStyle = FlatStyle.Flat;
            btnCancelar.Font = new Font("Century Gothic", 10F, FontStyle.Bold);
            btnCancelar.ForeColor = Color.White;
            btnCancelar.Location = new Point(197, 308);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(160, 60);
            btnCancelar.TabIndex = 15;
            btnCancelar.Text = "Cancel";
            btnCancelar.UseVisualStyleBackColor = false;
            btnCancelar.Click += btnCancelar_Click_1;
            // 
            // FormAñadirProducto
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(232, 239, 253);
            ClientSize = new Size(655, 596);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxPrice);
            Controls.Add(textBoxDescription);
            Controls.Add(textBoxName);
            Controls.Add(panel1);
            Name = "FormAñadirProducto";
            Text = "FormAñadirProducto";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGuardar;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBoxPrice;
        private TextBox textBoxDescription;
        private TextBox textBoxName;
        private Panel panel1;
        private Button btnCancelar; 
    }
}