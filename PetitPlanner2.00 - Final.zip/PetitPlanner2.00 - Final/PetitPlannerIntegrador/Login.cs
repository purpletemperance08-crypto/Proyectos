﻿using MySqlConnector;
using System;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    public partial class LoginControl : UserControl
    {
        public event EventHandler LoginExitoso;
        public event EventHandler<string> LoginFallido;
        public event EventHandler IrACreateAccount;


        public LoginControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string usuario = textBoxUsuario.Text;
            string password = textBoxPassword.Text;

            if (string.IsNullOrEmpty(usuario) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT id_user FROM usuarios WHERE user = @usuario AND password = @password";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@usuario", usuario);
                        command.Parameters.AddWithValue("@password", password);

                        object idResult = command.ExecuteScalar();

                        string userId = null;

                        if (idResult != null && idResult != DBNull.Value)
                        {
                            userId = idResult.ToString();
                        }

                        if (!string.IsNullOrEmpty(userId))
                        {
                            incorrectUser.Text = "";
                            incorrectUser.Visible = false;
                            SessionManager.StartSession(userId);
                            LoginExitoso?.Invoke(this, EventArgs.Empty);
                        }
                        else
                        {
                            incorrectUser.Text = "Usuario o contraseña incorrecta";
                            incorrectUser.Visible = true;
                            LoginFallido?.Invoke(this, "Credenciales incorrectas");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error de conexión o de base de datos: {ex.Message}");
                LoginFallido?.Invoke(this, ex.Message);
            }
        }

        public void LimpiarCampos()
        {
            textBoxUsuario.Text = "";
            textBoxPassword.Text = "";
        }

        private void createAccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            IrACreateAccount?.Invoke(this, EventArgs.Empty);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBoxPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}