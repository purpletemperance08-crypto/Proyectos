﻿// PetitPlannerIntegrador.Models/EventModel.cs

using System;

namespace PetitPlannerIntegrador.Models
{
    public class EventModel
    {
        // Propiedades de la base de datos (tabla de eventos)
        public string IdCalender { get; set; }
        public string IdEvent { get; set; }
        public string Name { get; set; }
        public string Eventhour { get; set; }
        public string Date { get; set; }
        public string Description { get; set; }

        // Nuevas propiedades de la base de datos (tabla de eventos)
        public string Ubication { get; set; }   // Corresponde a 'ubication'
        public string NumberPhone { get; set; } // Corresponde a 'numberPhone'
        public string TypeEvent { get; set; }   // Corresponde a 'typeEvent'
        public decimal Monto { get; set; }      // Corresponde a 'monto'

        // 🔑 NUEVA PROPIEDAD para mapear directamente el campo 'state' de la DB
        // Esto es un INT en la DB (0 o 1). Lo hacemos int? para manejar posibles nulos o errores.
        public int? State { get; set; }

        // 🔑 Propiedad de solo lectura para el DataGridView y la lógica de negocio.
        // Ahora usa el valor de 'State' de la DB.
        /// <summary>
        /// Indica si el evento está pagado (State = 1) o pendiente (State = 0).
        /// </summary>
        public bool IsPaid
        {
            get
            {
                return State == 1;
            }
           
        }

        public string DisplaySummary
        {
            get
            {
                // Incluimos TypeEvent en el resumen para hacerlo más útil
                return $"{Name} - {TypeEvent} ({Date})";
            }
        }
    }
}