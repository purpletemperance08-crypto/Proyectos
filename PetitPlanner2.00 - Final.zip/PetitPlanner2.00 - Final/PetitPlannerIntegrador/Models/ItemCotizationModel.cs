﻿using System;

namespace PetitPlannerIntegrador.Models
{
    public class ItemCotizacionModel
    {
        // Propiedades de tu producto
        public string IdProducto { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        // La propiedad Price del modelo original es string, pero para cálculos debe ser decimal.
        public decimal PrecioUnitario { get; set; }

        // Propiedad específica del carrito
        public int Cantidad { get; set; }

        // Propiedad calculada: el subtotal de esta línea
        public decimal Subtotal
        {
            get { return Cantidad * PrecioUnitario; }
        }

        public ItemCotizacionModel(productModel producto, int cantidad)
        {
            this.IdProducto = producto.IdProducto;
            this.Name = producto.Name;
            this.Description = producto.Description;
            // Es crucial intentar convertir el Price a decimal para el cálculo
            if (decimal.TryParse(producto.Price.ToString(), out decimal priceValue))
            {
                this.PrecioUnitario = priceValue;
            }
            else
            {
                // Manejo de error si el precio no es un número válido
                this.PrecioUnitario = 0m;
            }
            this.Cantidad = cantidad;
        }
    }
}