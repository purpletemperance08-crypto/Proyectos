﻿namespace PetitPlannerIntegrador.Models
{
    public class InventarioItem
    {
        public int id_catalog { get; set; }

        public int id_inventory { get; set; }

        public string name { get; set; }

        public string description { get; set; }

        public int stock { get; set; }
    }
}