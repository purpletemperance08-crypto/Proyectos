﻿using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    public partial class FormAñadirCatalog : Form
    {
        private readonly string _idInventory;
        // 🛑 CAMBIO CLAVE: Usamos el repositorio de Catálogo
        private CatalogRepositorie _repo = new CatalogRepositorie();

        public FormAñadirCatalog(string idInventory)
        {
            InitializeComponent();
            _idInventory = idInventory;
            this.Text = "Añadir Nuevo Artículo al Catálogo: " + idInventory;
        }


        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click_1(object sender, EventArgs e) // Cambié el nombre del manejador a btnGuardar_Click para evitar duplicados
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string Nombre = textBoxName.Text.Trim();
            string Descripcion = textBoxDescription.Text.Trim();
            // 🛑 CAMBIO CLAVE: Obtener el texto del Stock
            string StockTexto = textBoxStock.Text.Trim();

            if (string.IsNullOrEmpty(Nombre) || string.IsNullOrEmpty(Descripcion) || string.IsNullOrEmpty(StockTexto))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 🛑 VALIDACIÓN CLAVE: El stock debe ser un entero positivo o cero
            if (!int.TryParse(StockTexto, out int Stock) || Stock < 0)
            {
                MessageBox.Show("Por favor, ingrese un valor de Stock válido (número entero positivo o cero).", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // Asumo que el textbox para stock se llama textBoxStock
                textBoxStock.Focus();
                return;
            }

            try
            {
                if (!int.TryParse(_idInventory, out int idInventarioInt))
                {
                    MessageBox.Show("Error de sesión: El ID de inventario no es un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                _repo.AddItem(idInventarioInt, Nombre, Descripcion, Stock);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error al añadir el artículo de catálogo: {ex.InnerException?.Message ?? ex.Message}",
                                "Error de Base de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}