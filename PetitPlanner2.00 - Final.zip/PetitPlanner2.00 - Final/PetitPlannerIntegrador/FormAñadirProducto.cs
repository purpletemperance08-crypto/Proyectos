﻿using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories; 
using System;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    public partial class FormAñadirProducto : Form
    {
        private readonly string _idInventory;
        private ProductRepositorie _repo = new ProductRepositorie();

        public FormAñadirProducto(string idInventory)
        {
            InitializeComponent();
            _idInventory = idInventory;
            this.Text = "Añadir Nuevo Artículo al Inventario: " + idInventory;
        }


        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            {
                string Nombre = textBoxName.Text.Trim();
                string Descripcion = textBoxDescription.Text.Trim();
                string PrecioTexto = textBoxPrice.Text.Trim();

                if (string.IsNullOrEmpty(Nombre) || string.IsNullOrEmpty(Descripcion) || string.IsNullOrEmpty(PrecioTexto))
                {
                    MessageBox.Show("Por favor, complete todos los campos.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {

                    _repo.AddProduct(Nombre, Descripcion, PrecioTexto, _idInventory);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"❌ Error al añadir el producto: {ex.InnerException?.Message ?? ex.Message}",
                                    "Error de Base de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.DialogResult = DialogResult.Cancel;
                }
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}