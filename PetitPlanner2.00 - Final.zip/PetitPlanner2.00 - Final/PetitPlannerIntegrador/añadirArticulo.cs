﻿using MySqlConnector;
using PetitPlannerIntegrador.Models; // Necesario para acceder a ProductRepositorie y Models
using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;

namespace PetitPlannerIntegrador
{
    public partial class añadirArticulo : UserControl
    {
        public event EventHandler ArticuloAgregado;
        public event EventHandler Cancelar;
        public event EventHandler VolverAtras;



        public añadirArticulo()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            cargarDatosProductos();
            Eliminar.Click += Eliminar_Click;
            Editar.Click += Editar_Click_1;
        }

        private void Editar_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, seleccione una fila completa para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

            string idProducto = selectedRow.Cells["IdProducto"].Value.ToString();

            using (FormEditarProducto formEdicion = new FormEditarProducto(idProducto))
            {
                formEdicion.StartPosition = FormStartPosition.CenterScreen;

                DialogResult result = formEdicion.ShowDialog();

                if (result == DialogResult.OK)
                {
                    cargarDatosProductos();
                }
            }
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string idProducto = dataGridView1.SelectedRows[0].Cells["IdProducto"].Value.ToString();

                DialogResult confirm = MessageBox.Show(
                    $"¿Estás seguro de que quieres eliminar el producto?",
                    "Confirmar Eliminación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm == DialogResult.Yes)
                {
                    try
                    {
                        ProductRepositorie repo = new ProductRepositorie();
                        repo.DeleteProduct(idProducto);

                        MessageBox.Show("✅ Producto eliminado exitosamente.");
                        cargarDatosProductos();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"❌ Error al eliminar el producto: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una fila completa para eliminar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cargarDatosProductos()
        {
            ProductRepositorie repo = new ProductRepositorie();
            var productos = repo.GetProductsByInventoryId(SessionManager.CurrentIdInventory);
            dataGridView1.DataSource = productos;

            if (string.IsNullOrEmpty(SessionManager.CurrentIdInventory))
            {
                dataGridView1.DataSource = null;
                MessageBox.Show("Error: ID de Inventario no cargado.", "Error de Sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dataGridView1.Columns.Contains("IdInventario"))
            {
                dataGridView1.Columns["IdInventario"].Visible = false;
            }

            if (dataGridView1.Columns.Contains("IdProducto"))
            {
                dataGridView1.Columns["IdProducto"].Visible = false;
            }
        }

        private void atras_Click(object sender, EventArgs e)
        {
            Cancelar?.Invoke(this, EventArgs.Empty);
        }

        private void backInventory_Click(object sender, EventArgs e)
        {
            VolverAtras?.Invoke(this, EventArgs.Empty);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string idInventarioActual = SessionManager.CurrentIdInventory;

            if (string.IsNullOrEmpty(idInventarioActual))
            {
                MessageBox.Show("Error: El ID de Inventario no está cargado en la sesión.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (FormAñadirProducto formAñadir = new FormAñadirProducto(idInventarioActual))
            {
                formAñadir.StartPosition = FormStartPosition.CenterScreen;

                DialogResult result = formAñadir.ShowDialog();

                if (result == DialogResult.OK)
                {
                    cargarDatosProductos();
                }
            }
        }

        private void Eliminar_Click_1(object sender, EventArgs e)
        {

        }
    }
}