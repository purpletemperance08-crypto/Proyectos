﻿using MySqlConnector;
using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PetitPlannerIntegrador
{
    public partial class agendarEvento : UserControl
    {
        private string idCalender;
        private string IdInventorio;

        public event EventHandler IrAInventario;
        public event EventHandler IrAInicio;
        public event EventHandler IrACalendario;
        public event EventHandler IrAAgendarEvento;
        public event EventHandler EventoAgregado;
        public event EventHandler IrARealizarCotizacion;
        public event EventHandler IrAProfile;
        public event EventHandler ArticuloAgregado;
        public event EventHandler IrACatalog;

        public agendarEvento()
        {
            InitializeComponent();
            DatosDelNegocio();
            CargarMontoCotizado();

            this.numberPhoneEvent.Text = string.Empty;
            this.nameLabel.Focus();
        }

        private void agendarEvento_Load(object sender, EventArgs e)
        {
            // Configuración del Scroll
            panel4.AutoScroll = true;

            // Forzar el centrado inicial
            CentrarPanelContenido();

            // Suscribirse al evento de cambio de tamaño
            this.Resize += AgendarEvento_Resize;
        }

        private void AgendarEvento_Resize(object sender, EventArgs e)
        {
            CentrarPanelContenido();
        }

        private void CentrarPanelContenido()
        {
            // Logica simple para centrar el panelContenido dentro del panel4
            if (panel4.Width > panelContenido.Width)
            {
                int x = (panel4.Width - panelContenido.Width) / 2;
                // Mantenemos un margen superior fijo o relativo al header
                int y = 20;

                // Si hay mucho espacio vertical, lo centramos también verticalmente (opcional)
                // pero como quieres scroll, mejor dejarlo arriba con un margen.
                panelContenido.Location = new Point(x, panel5.Height + 20);
            }
            else
            {
                // Si la pantalla es muy estrecha, pegamos a la izquierda
                panelContenido.Location = new Point(20, panel5.Height + 20);
            }
        }

        public void CargarMontoCotizado()
        {
            decimal montoTemporal = SessionManager.MontoCotizacionTemporal;

            if (montoTemporal != 0m)
            {
                montoEvent.Text = montoTemporal.ToString("N2");
                SessionManager.MontoCotizacionTemporal = 0m;
            }
        }

        private void DatosDelNegocio()
        {
            CalenderRepositorie repo = new CalenderRepositorie();
            CalenderModel? usuarioActivo = repo.UserInformation();

            if (usuarioActivo != null)
            {
                idCalender = usuarioActivo.idCalender;
                SessionManager.setIdCalender(idCalender);
            }
            else
            {
                MessageBox.Show("Error al cargar la información de usuario o sesión expirada.");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string nombre = nameLabel.Text;
            DateTime fechaSola = dateEvent.Value.Date;
            TimeSpan horaSola = hourEvent.Value.TimeOfDay;
            string descripcion = descriptionLabel.Text;
            string ubicacion = ubicationEvent.Text;
            string numeroTelefono = numberPhoneEvent.Text;
            string tipoEvento = typeEvent.Text;
            string montoEventoString = montoEvent.Text;
            decimal? montoEventoDecimal = null;

            if (decimal.TryParse(montoEventoString, out decimal result))
            {
                montoEventoDecimal = result;
            }

            SessionManager.setIdCalender(idCalender);

            if (string.IsNullOrEmpty(idCalender))
            {
                MessageBox.Show("❌ Error: ID de Calendario no disponible. Intente iniciar sesión nuevamente.");
                return;
            }

            string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";
            string query = @"INSERT INTO event (id_calender, name, date, eventhour, ubication, description, numberPhone, typeEvent, monto) 
                             VALUES (@id_calender, @nombre, @fechasola, @hora, @ubication, @description, @numberPhone, @typeEvent, @Monto)";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id_calender", idCalender);
                        command.Parameters.AddWithValue("@nombre", nombre);
                        command.Parameters.AddWithValue("@fechasola", fechaSola);
                        command.Parameters.AddWithValue("@hora", horaSola);
                        command.Parameters.AddWithValue("@ubication", ubicacion);
                        command.Parameters.AddWithValue("@description", descripcion);
                        command.Parameters.AddWithValue("@numberPhone", numeroTelefono);
                        command.Parameters.AddWithValue("@typeEvent", tipoEvento);
                        command.Parameters.AddWithValue("@Monto", montoEventoDecimal.HasValue ? (object)montoEventoDecimal.Value : DBNull.Value);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("✅ Evento agregado exitosamente.");
                            nameLabel.Text = string.Empty;
                            descriptionLabel.Text = string.Empty;
                            ubicationEvent.Text = string.Empty;
                            numberPhoneEvent.Text = string.Empty;
                            typeEvent.Text = string.Empty;
                            montoEvent.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show("⚠️ El evento no se pudo agregar (Cero filas afectadas).");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error al agregar el evento: {ex.Message}\nVerifique la conexión y los tipos de datos en la base de datos.");
            }
        }

        private void homePage_Click(object sender, EventArgs e)
        {
            IrAInicio?.Invoke(this, EventArgs.Empty);
        }

        private void inventary_Click(object sender, EventArgs e)
        {
            IrACatalog?.Invoke(this, EventArgs.Empty);
        }

        private void calendario_Click(object sender, EventArgs e)
        {
            IrACalendario?.Invoke(this, EventArgs.Empty);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IrARealizarCotizacion?.Invoke(this, EventArgs.Empty);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            IrAProfile?.Invoke(this, EventArgs.Empty);
        }

        private void panel4_Paint(object sender, PaintEventArgs e) { }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Catalogo_Click(object sender, EventArgs e)
        {
            IrAInventario?.Invoke(this, EventArgs.Empty);
        }
    }
}