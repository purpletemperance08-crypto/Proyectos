﻿using MySqlConnector;
using PetitPlannerIntegrador.Models;
using System;
using System.Collections.Generic;
using System.Linq;

// La clase modelo InventarioItem que creamos anteriormente es la que usaremos para mapear la tabla 'catalog'
// (asumo que la clase InventarioItem está definida en PetitPlannerIntegrador.Models)

public class CatalogRepositorie
{
    // Usa la misma cadena de conexión
    private readonly string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";

    // --- 1. OBTENER LISTA POR ID DE INVENTARIO ---
    public List<InventarioItem> GetCatalogItemsByInventoryId(string inventoryId)
    {
        // Se cambió 'catalog_table' por el nombre de tabla confirmado: 'catalog'
        string query = @"SELECT id_catalog, id_inventory, name, description, stock 
                         FROM catalog 
                         WHERE id_inventory = @idInventory";

        List<InventarioItem> items = new List<InventarioItem>();

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idInventory", inventoryId);
                    connection.Open();

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            items.Add(new InventarioItem
                            {
                                id_catalog = reader.GetInt32("id_catalog"),
                                id_inventory = reader.GetInt32("id_inventory"),
                                name = reader.GetString("name"),
                                description = reader.GetString("description"),
                                stock = reader.GetInt32("stock")
                            });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error en CatalogRepositorie.GetCatalogItemsByInventoryId: {ex.Message}");
            throw new Exception("Error al obtener artículos del catálogo.", ex);
        }

        return items;
    }

    // --- 2. OBTENER POR ID DE CATÁLOGO ---
    public InventarioItem GetItemById(int idCatalog)
    {
        string query = @"SELECT id_catalog, id_inventory, name, description, stock 
                         FROM catalog 
                         WHERE id_catalog = @idCatalog";

        InventarioItem item = null;

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idCatalog", idCatalog);
                    connection.Open();

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            item = new InventarioItem
                            {
                                id_catalog = reader.GetInt32("id_catalog"),
                                id_inventory = reader.GetInt32("id_inventory"),
                                name = reader.GetString("name"),
                                description = reader.GetString("description"),
                                stock = reader.GetInt32("stock")
                            };
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al obtener el artículo por ID de catálogo {idCatalog}.", ex);
        }

        return item;
    }

    // --- 3. ACTUALIZAR ARTÍCULO ---
    public void UpdateItem(int idCatalog, string name, string description, int stock)
    {
        string query = @"UPDATE catalog 
                         SET name = @name, description = @description, stock = @stock 
                         WHERE id_catalog = @idCatalog";

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idCatalog", idCatalog);
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@description", description);
                    command.Parameters.AddWithValue("@stock", stock);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al actualizar el artículo con ID {idCatalog} en el repositorio.", ex);
        }
    }

    // --- 4. ELIMINAR ARTÍCULO ---
    public void DeleteItem(int idCatalog)
    {
        string query = "DELETE FROM catalog WHERE id_catalog = @idCatalog";

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idCatalog", idCatalog);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al eliminar el artículo con ID {idCatalog} en el repositorio.", ex);
        }
    }

    // --- 5. INSERTAR (AÑADIR) ARTÍCULO ---
    public void AddItem(int idInventory, string name, string description, int stock)
    {
        string query = @"INSERT INTO catalog (id_inventory, name, description, stock) 
                         VALUES (@idInventory, @nombre, @descripcion, @stock)";

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idInventory", idInventory);
                    command.Parameters.AddWithValue("@nombre", name);
                    command.Parameters.AddWithValue("@descripcion", description);
                    command.Parameters.AddWithValue("@stock", stock);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al agregar el artículo '{name}' en el catálogo.", ex);
        }
    }
}