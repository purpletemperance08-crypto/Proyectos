﻿// EventRepositorie.cs
using MySqlConnector;
using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador;
using System;
using System.Collections.Generic;
using System.Windows.Forms; // Añadido para que MessageBox funcione sin prefijo

namespace PetitPlannerIntegrador.Repositories
{
    public class EventRepositorie
    {
        private readonly string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";

        // 🔑 CORRECCIÓN 1: Se añade 'state AS State' a la consulta base
        private const string EventQueryBase =
            "SELECT id_event AS IdEvent, id_calender AS IdCalender, name AS Name, date AS Date, eventhour AS Eventhour, description AS Description, " +
            "ubication AS Ubication, numberPhone AS NumberPhone, typeEvent AS TypeEvent, monto AS Monto, state AS State FROM event ";


        public List<EventModel> GetEventsByCalenderId(string idCalender)
        {
            List<EventModel> listaEventos = new List<EventModel>();

            if (string.IsNullOrEmpty(idCalender))
            {
                return listaEventos;
            }

            // Consulta completa con ORDER BY
            string query = EventQueryBase + "WHERE id_calender = @idCalender ORDER BY date, eventhour";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@idCalender", idCalender);
                        connection.Open();

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaEventos.Add(MapReaderToEventModel(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show($"Error al cargar eventos: {ex.Message}");
            }

            return listaEventos;
        }

        // ... (UserInformation y MapReaderToEventModel no necesitan cambios por la corrección 1)

        private EventModel MapReaderToEventModel(MySqlDataReader reader)
        {
            // Usamos GetOrdinal y IsDBNull para manejar valores NULL de la base de datos
            string ubication = reader.IsDBNull(reader.GetOrdinal("Ubication")) ? string.Empty : reader["Ubication"].ToString()!;
            string description = reader.IsDBNull(reader.GetOrdinal("Description")) ? string.Empty : reader["Description"].ToString()!;
            decimal monto = reader.IsDBNull(reader.GetOrdinal("Monto")) ? 0.00m : Convert.ToDecimal(reader["Monto"]);
            // 🔑 Se incluye la lectura de State
            int state = reader.IsDBNull(reader.GetOrdinal("State")) ? 0 : Convert.ToInt32(reader["State"]);


            return new EventModel
            {
                IdEvent = reader["IdEvent"].ToString()!,
                IdCalender = reader["IdCalender"].ToString()!,
                Name = reader["Name"].ToString()!,
                Eventhour = reader["Eventhour"].ToString()!,
                Date = reader["Date"].ToString()!,
                Description = description,
                Ubication = ubication,
                NumberPhone = reader["NumberPhone"].ToString()!,
                TypeEvent = reader["TypeEvent"].ToString()!,
                Monto = monto,
                // 🔑 Se asigna el State
                State = state
            };
        }

        public bool EliminarEvento(string idEvent)
        {
            if (string.IsNullOrEmpty(idEvent))
            {
                return false;
            }

            string query = "DELETE FROM event WHERE id_event = @idEvent";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@idEvent", idEvent);
                        connection.Open();

                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar evento: {ex.Message}");
                return false;
            }
        }

        public bool MarcarComoPagado(string idEvento)
        {
            if (string.IsNullOrEmpty(idEvento))
            {
                return false;
            }

            // 🔑 CORRECCIÓN 2: Cambiar la columna 'IsPaid' por 'State'
            string query = "UPDATE event SET State = 1 WHERE id_event = @idEvento";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@idEvento", idEvento);

                        connection.Open();

                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al marcar evento como pagado: {ex.Message}");
                return false;
            }
        }
    }
}