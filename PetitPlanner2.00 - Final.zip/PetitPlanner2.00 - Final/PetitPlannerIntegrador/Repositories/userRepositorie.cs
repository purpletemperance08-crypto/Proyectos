﻿using MySqlConnector;
using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador;
using System;

namespace PetitPlannerIntegrador.Repositories
{
    public class UserRepositorie
    {
        private readonly string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";

        public userModel UserInformation()
        {
            string userId = SessionManager.CurrentUserId;

            if (string.IsNullOrEmpty(userId))
            {
                return null;
            }

            string query = "SELECT user AS Nombre, email AS Email, id_user AS IdUser, password AS Password FROM usuarios WHERE id_user = @id";
            userModel usuario = null;

            try // Añadir un bloque try-catch es crucial para manejo de errores de DB
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", userId);
                        connection.Open();

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                usuario = new userModel
                                {
                                    IdUser = userId, 
                                    Nombre = reader["Nombre"].ToString()!, 
                                    Email = reader["Email"].ToString()!,
                                    Password= reader["Password"].ToString()!,

                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de error si la conexión falla (opcional, pero recomendado)
                // System.Windows.Forms.MessageBox.Show($"Error de base de datos: {ex.Message}");
                return null;
            }

            return usuario;
        }
    }
}