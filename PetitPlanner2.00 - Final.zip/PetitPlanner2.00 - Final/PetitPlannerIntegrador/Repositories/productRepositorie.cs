﻿using MySqlConnector;
using PetitPlannerIntegrador;
using PetitPlannerIntegrador.Models;
using System;
using System.Collections.Generic;
using System.Linq;


public class ProductRepositorie
{
    private readonly string connectionString = "Server=localhost;Database=petitplanner;Uid=root;Pwd=root;";

    // 1. OBTENER LISTA (Usado por añadirArticulo para llenar el DataGridView)
    public List<productModel> GetProductsByInventoryId(string inventoryId)
    {
        string query = "SELECT id_product AS IdProducto, name AS Name, price AS Price, description AS Description " +
                       "FROM product WHERE id_inventory = @id";

        List<productModel> productos = new List<productModel>();

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", inventoryId);
                    connection.Open();

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            productModel product = new productModel
                            {
                                IdInventario = inventoryId,
                                IdProducto = reader["IdProducto"].ToString()!,
                                Name = reader["Name"].ToString()!,
                                Description = reader["Description"].ToString()!,
                                // 💡 Mejor práctica: Lee el precio como decimal o double si es posible.
                                // Si tu modelo usa string para Price, esta línea está bien:
                                Price = decimal.Parse(reader["Price"].ToString()!),
                            };
                            productos.Add(product);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error en ProductRepositorie: {ex.Message}");
            // En un repositorio, es mejor relanzar la excepción o devolver una lista vacía
            throw new Exception("Error al obtener productos.", ex);
        }

        return productos;
    }

    // 2. OBTENER POR ID (Usado por FormEditarProducto)
    public productModel GetProductById(string idProducto)
    {
        string query = "SELECT id_product AS IdProducto, name AS Name, price AS Price, description AS Description, id_inventory AS IdInventario " +
                       "FROM product WHERE id_product = @idProducto";

        productModel product = null;

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idProducto", idProducto);
                    connection.Open();

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            product = new productModel
                            {
                                IdProducto = reader["IdProducto"].ToString()!,
                                Name = reader["Name"].ToString()!,
                                Description = reader["Description"].ToString()!,
                                Price = decimal.Parse(reader["Price"].ToString()!),
                                IdInventario = reader["IdInventario"].ToString()!
                            };
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al obtener el producto por ID {idProducto}.", ex);
        }

        return product;
    }

    // 3. ACTUALIZAR (Usado por FormEditarProducto)
    public void UpdateProduct(string idProducto, string name, string description, decimal price)
    {
        string query = @"UPDATE product 
                          SET name = @name, description = @description, price = @price 
                          WHERE id_product = @idProducto";

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idProducto", idProducto);
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@description", description);
                    command.Parameters.AddWithValue("@price", price);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al actualizar el producto con ID {idProducto} en el repositorio.", ex);
        }
    }

    // 4. ELIMINAR (Usado por añadirArticulo)
    public void DeleteProduct(string idProducto)
    {
        string query = "DELETE FROM product WHERE id_product = @idProducto";

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idProducto", idProducto);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al eliminar el producto con ID {idProducto} en el repositorio.", ex);
        }
    }

    // 5. INSERTAR (AÑADIR) -> MÉTODO FALTANTE (SOLUCIÓN AL ERROR CS1061)
    public void AddProduct(string name, string description, String price, string idInventory)
    {
        string query = @"INSERT INTO product (Name, Description, Price, id_inventory) 
                         VALUES (@nombre, @descripcion, @precio, @id_inventory)";

        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@nombre", name);
                    command.Parameters.AddWithValue("@descripcion", description);
                    command.Parameters.AddWithValue("@precio", price); command.Parameters.AddWithValue("@id_inventory", idInventory);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            // Relanzamos la excepción para que el UserControl la maneje
            throw new Exception($"Error al agregar el producto '{name}' en el repositorio.", ex);
        }
    }



    // Mantener el método original por compatibilidad, aunque GetProductsByInventoryId es la mejor opción.
    public productModel UserInformation()
    {
        string idInventory = SessionManager.CurrentIdInventory;
        var productos = GetProductsByInventoryId(idInventory);
        return productos.FirstOrDefault();
    }

   

}