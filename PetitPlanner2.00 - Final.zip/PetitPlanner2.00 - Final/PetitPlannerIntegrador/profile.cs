﻿using PetitPlannerIntegrador.Models;
using PetitPlannerIntegrador.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace PetitPlannerIntegrador
{
    public partial class profile : UserControl
    {
        private string idUser;
        private string idEvent;
        private string eventName;
        private string eventHour;
        private string eventDescription;
        private string dateEvent;


        public event EventHandler IrAInicio;
        public event EventHandler IrACalendario;
        public event EventHandler IrAInventario;
        public event EventHandler IrAAgendarEvento;
        public event EventHandler cerrarSesion;
        public event EventHandler IrACatalog;

        public profile()
        {
            InitializeComponent();
            CargarDatosUsuario();
        }

        private void CargarDatosUsuario()
        {

            UserRepositorie repo = new UserRepositorie();
            userModel? usuarioActivo = repo.UserInformation();
            string textoEstatico = "Este es tu email: ";
            string emailDelUsuario = usuarioActivo.Email;
            emailUser.Text = $"{textoEstatico}{usuarioActivo.Email}";
            emailUser.SelectionStart = 0;
            emailUser.SelectionLength = textoEstatico.Length;
            emailUser.SelectionFont = new Font(emailUser.Font, FontStyle.Bold);

            SizeF size = emailUser.CreateGraphics().MeasureString(
                emailUser.Text,
                emailUser.Font,
                emailUser.Width
            );
            emailUser.Height = (int)Math.Ceiling(size.Height);

            string textoEstaticoUsuario = "Nombre de Usuario: ";
            string nombreDeUsuario = usuarioActivo.Nombre;
            userName.Text = $"{textoEstaticoUsuario}{usuarioActivo.Nombre}";
            userName.SelectionStart = 0;
            userName.SelectionLength = textoEstatico.Length;
            userName.SelectionFont = new Font(userName.Font, FontStyle.Bold);

            SizeF sizeUsuario = userName.CreateGraphics().MeasureString(
                userName.Text,
                userName.Font,
                userName.Width
            );
            userName.Height = (int)Math.Ceiling(size.Height);

            string textoEstaticoPassword = "Password: ";
            string passwordUsuario = usuarioActivo.Password;
            string asteriscos = new string('*', passwordUsuario.Length);
            passwordUser.Text = $"{textoEstaticoPassword}{asteriscos}";
            passwordUser.SelectionStart = 0;
            passwordUser.SelectionLength = textoEstaticoPassword.Length;
            passwordUser.SelectionFont = new Font(userName.Font, FontStyle.Bold);

            SizeF sizePassword = passwordUser.CreateGraphics().MeasureString(
                passwordUser.Text,
                passwordUser.Font,
                passwordUser.Width
            );
            passwordUser.Height = (int)Math.Ceiling(size.Height);
            BussinesRepositorie rapo = new BussinesRepositorie();
            bussinesModel? usuarioActivoo = rapo.UserInformation();

            if (usuarioActivoo != null)
            {
                string textoEstaticoNombreBussines = "Nombre del Negocio: ";
                string nombreDeBussines = usuarioActivoo.name;
                userBussinesName.Text = $"{textoEstaticoNombreBussines}{usuarioActivoo.name}";
                userBussinesName.SelectionStart = 0;
                userBussinesName.SelectionLength = textoEstatico.Length;
                userBussinesName.SelectionFont = new Font(userBussinesName.Font, FontStyle.Bold);

                SizeF sizeBussines = userBussinesName.CreateGraphics().MeasureString(
                    userBussinesName.Text,
                    userBussinesName.Font,
                    userBussinesName.Width
                );
                userBussinesName.Height = (int)Math.Ceiling(size.Height);

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SessionManager.EndSession();
            cerrarSesion?.Invoke(this, EventArgs.Empty);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IrAInicio?.Invoke(this, EventArgs.Empty);
        }
        private void button5_Click(object sender, EventArgs e)
        {
            IrACatalog?.Invoke(this, EventArgs.Empty);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            IrACalendario?.Invoke(this, EventArgs.Empty);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            IrAAgendarEvento?.Invoke(this, EventArgs.Empty);
        }

        private void Catalogo_Click(object sender, EventArgs e)
        {
            IrAInventario?.Invoke(this, EventArgs.Empty);
        }
    }
}